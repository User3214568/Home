import Fetch from "./fetch.js";
new Fetch('/admin/formation/professeurs/');
