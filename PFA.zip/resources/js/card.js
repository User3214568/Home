$(document).ready(function(){
    $(".card-formation-module ")
})
