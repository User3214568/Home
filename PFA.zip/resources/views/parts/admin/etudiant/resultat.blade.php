<script type="module" src="/javascript/notes.js"></script>

@extends('parts.admin.etudiant.evaluation')

@section('title_ad','Résultats des Etudiants')
@section('target','result')


