<div class="table-responsive">
    <table class="table">
        <tr>
            <th>CIN</th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Date de Naissance</th>
            <th>Lieu de Naissance</th>
            <th>Numéro de Téléphone</th>
        </tr>
        <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($history->etudiant)): ?>
        <tr>
            <td><?php echo e($history->etudiant_cin); ?></td>
            <td><?php echo e($history->etudiant->first_name); ?></td>
            <td><?php echo e($history->etudiant->last_name); ?></td>
            <td><?php echo e($history->etudiant->born_date); ?></td>
            <td><?php echo e($history->etudiant->born_place); ?></td>
            <td><?php echo e($history->etudiant->phone); ?></td>
        </tr>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\old\list-etudiants.blade.php ENDPATH**/ ?>