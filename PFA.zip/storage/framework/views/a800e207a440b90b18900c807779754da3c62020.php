<?php
    $route = route('module.store');
    if(isset($module)){
        $route = route('module.update',$module->id);
    }
    $fields = [
        ['type'=>'text', 'name'=>'name' ,'value' => isset($module)?$module->name:'' , 'label'=>'Nom du Module'],
        ['type'=>'textarea', 'name'=>'description' ,'value' => isset($module)?$module->description:'', 'label'=>'Description du Module'],
    ];
    $target = 'Module';

?>
<?php echo $__env->make('parts.admin.common.formulaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/module/module.blade.php ENDPATH**/ ?>