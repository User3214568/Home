
<div class="row mt-4 ">
    <h2>Gestion des Notes Par Module</h2>
</div>
<div class="row mt-1"><hr class="dropdown-divider"></div>
<div class="row">

</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\etudiant\note-module.blade.php ENDPATH**/ ?>