
<?php
    $route = route('depense.store');
    if(isset($dep)){
        $route = route('depense.update',$dep);
    }


    $fields = [
        ['type'=>'text', 'name'=>'name' ,'value' => isset($dep)?$dep->name:'' , 'label'=>'Motif'],
        ['type'=>'text', 'name'=>'somme' ,'value' => isset($dep)?$dep->somme:'', 'label'=>'Somme'],
    ];


    $target = "Dépense";
?>
<?php echo $__env->make('parts.admin.common.formulaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/common/depense/create.blade.php ENDPATH**/ ?>