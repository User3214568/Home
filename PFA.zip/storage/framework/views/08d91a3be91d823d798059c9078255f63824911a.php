<div class="row">
    <h2>Acceuil</h2>
    <hr class="dropdown-divider">
</div>
<div class="table-responsive mt-4">
    <h5>Informations Personnel</h5>
    <table class="table table-border">
        <tr>
            <th>Nom</th>
            <td><?php echo e(Auth::user()->first_name); ?></td>
            <th>Prénom</th>
            <td><?php echo e(Auth::user()->last_name); ?></td>
        </tr>
        <tr>
            <th>Carte D'identite Nationale</th>
            <td><?php echo e(Auth::user()->cin); ?></td>
            <th>Num Télephone</th>
            <td><?php echo e(Auth::user()->phone); ?></td>
        </tr>
    </table>
</div>
<div class="table-responsive mt-4">
    <h5>Mon Historique</h5>
    <div class="container">
        <ul class="timeline">
            <?php $__currentLoopData = $affectations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $au=>$items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="timeline-badge primary">
                        <i class="fa fa-clipboard-list"></i>
                    </div>
                    <div class="timeline-panel">
                        <div class="timeline-heading">
                            <h5 class="timeline-title"><?php echo e($au."-".($au+1)); ?></h5>
                        </div>
                        <div class="timeline-body">
                            <table class="table table-border">
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->module->name); ?></td>
                                    <td><?php echo e($item->formation->name); ?></td>
                                    <td><?php echo e($item->somme); ?></td>
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>



<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/enseignant/home.blade.php ENDPATH**/ ?>