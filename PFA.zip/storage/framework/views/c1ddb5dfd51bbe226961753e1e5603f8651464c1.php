<div class="table-responsive">

    <table class="table align-middle">
        <tr>
            <th>CIN</th>
            <th>Nom et Prénom</th>
            <th>Note Finale</th>
        <th>Résultat Finale</th>
    </tr>
    <?php
        $count = 0 ; $moy = 0;
    ?>
    <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(isset($history->etudiant)): ?>
    <?php $__currentLoopData = $history->hisresults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hisresult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $moy += $hisresult->note_final;
            $count++;
        ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($history->etudiant_cin); ?></td>
        <td><?php echo e($history->etudiant->name()); ?></td>
        <td>
            <?php echo e(number_format(($count != 0)?$moy/$count:0,2)); ?>

        </td>
        <td>
            <?php echo e(\App\Utilities\Validation::resultDesc($history->etudiant->formation,$moy,1)); ?>

        </td>
    </tr>
    <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\old\all-result.blade.php ENDPATH**/ ?>