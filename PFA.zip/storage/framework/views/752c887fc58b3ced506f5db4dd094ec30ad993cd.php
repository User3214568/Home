<script type="module" src="/javascript/notes.js"></script>



<?php $__env->startSection('title_ad','Résultats des Etudiants'); ?>
<?php $__env->startSection('target','result'); ?>



<?php echo $__env->make('parts.admin.etudiant.evaluation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/etudiant/resultat.blade.php ENDPATH**/ ?>