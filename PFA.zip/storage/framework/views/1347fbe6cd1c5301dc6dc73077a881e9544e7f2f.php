<script type="module" src="/javascript/upload-export.js"></script>

<div class="row">
    <h2>Importer des Etudiant</h2>
    <hr class="dropdown-divider">
</div>
<div class="row">
    <p class="text-reset">
        La liste ci-dessous contient la list des etudiants qui peuvent etre importer.
    </p>
</div>
<div class="row p-4 table-responsive">
    <table class="table align-middle table-hover text-nowrap" id="etudiants-table">
        <thead>
            <tr>
                <th scope="col">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="checkAll" checked />
                        <label class="form-check-label" for="checkAll">

                        </label>
                    </div>
                </th>
                <th scope="col">Formation</th>
                <th scope="col">Nom</th>
                <th scope="col">Prénom</th>
                <th scope="col">CIN</th>
                <th scope="col">Date Naissance</th>
                <th scope="col">Lieu de Naissance</th>
                <th scope="col">Email</th>
                <td scope="col">Téléphone</td>
            </tr>
        </thead>
        <tbody>
            <?php if(isset($etudiants) && sizeof($etudiants) > 0): ?>

                <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td scope="row" name="selected">
                            <div class="form-check">
                                <input class="form-check-input etudiant-check" type="checkbox" value=""
                                    id="check_<?php echo e($etudiant->cin); ?>" checked />
                                <label class="form-check-label" for="check_<?php echo e($etudiant->cin); ?>"></label>
                            </div>
                        </td>
                        <td scope="row" name="formation_name"
                            formation="<?php echo e(isset($etudiant->formation) ? $etudiant->formation->id : ''); ?>">
                            <?php echo e(isset($etudiant->formation) ? $etudiant->formation->name : 'Undéfinie'); ?></td>
                        <td scope="row" name="first_name"><?php echo e($etudiant->first_name); ?></td>
                        <td scope="row" name="last_name"><?php echo e($etudiant->last_name); ?></td>
                        <td scope="row" name="cin"><?php echo e($etudiant->cin); ?></td>
                        <td scope="row" name="born_date"><?php echo e($etudiant->born_date); ?></td>
                        <td scope="row" name="born_place"><?php echo e($etudiant->born_place); ?></td>
                        <td scope="row" name="email"><?php echo e($etudiant->email); ?></td>
                        <td scope="row" name="phone"><?php echo e($etudiant->phone); ?></td>
                        <td scope="row" name="promotion_id"><?php echo e($etudiant->promotion_id); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table>
    <?php if(!isset($etudiants) || sizeof($etudiants) == 0): ?>
        <div scope="row">
            <p>Aucun etudiant à afficher.</p>
        </div>
    <?php endif; ?>

    <div class="d-flex justify-content-end">
        <button class="btn btn-success me-2" id="import-valider">Importer les Etudiants</button>
        <button class="btn btn-danger">Annuler L'importation</button>
    </div>

</div>
<button type="button" id="modal-trigger" class="btn btn-primary" data-toggle="modal" data-target="#popup"
        hidden>
    </button>
<?php echo $__env->make('parts.admin.common.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\etudiant\imported-list.blade.php ENDPATH**/ ?>