<script src="/javascript/delibration.js"></script>
<div class="row">
    <h2>Délibration</h2>
    <hr class="dropdown-divider">
</div>
<div class="row mt-4 justify-content-center">
    <select class="col-sm-5 p-2 me-3" name="formation" id="formation">
        <option value="0" disabled selected>Selectionner une Formation</option>
        <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($formation->id); ?>"><?php echo e($formation->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

</div>

<div  class="row mt-5 border justify-content-center p-3">
    <div class="col align-items-center" id="delib-info">
        <p class="text-center">Sélectionner une Formation puis une Promotion pour Confirmer la décision du fin d'année pour chaque étudiant</p>
    </div>
</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\etudiant\delibration.blade.php ENDPATH**/ ?>