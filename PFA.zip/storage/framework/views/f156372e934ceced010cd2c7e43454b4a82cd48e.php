<div class="row">
    <h2>Mes Résultats</h2>
    <hr class="dropdown-divider">
</div>
<div class="table-responsive">
    <table class="table table-border mt-3">
        <tr>
            <th>Module</th>
            <th>Note S. Ordinnaire</th>
            <th>Résultat S. Ordinnaire</th>
            <th>Note S. Rattrappage</th>
            <th>Résultat S. Rattrappage</th>
        </tr>
        <?php $__currentLoopData = $modules_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="<?php echo e(($item['result'][1]['result'] === "Validé" || $item['result'][2]['result'] === "Validé")?'text-success':'text-danger'); ?>">
                <th><?php echo e($item['name']); ?></th>
                <td><?php echo e($item['result'][1]['note']); ?></td>
                <td><?php echo e($item['result'][1]['result']); ?></td>
                <?php if($item['result'][1]['result'] === "Validé"): ?>
                    <td>-</td>
                    <td>-</td>
                <?php else: ?>
                    <td><?php echo e($item['result'][2]['note']); ?></td>
                    <td><?php echo e($item['result'][2]['result']); ?></td>
                <?php endif; ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/etudiant/results.blade.php ENDPATH**/ ?>