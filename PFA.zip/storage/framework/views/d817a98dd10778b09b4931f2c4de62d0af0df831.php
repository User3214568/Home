<!-- Tabs navs -->
<ul class="nav nav-tabs nav-justified mb-3" id="ex1" role="tablist">
    <?php
        $done = false;
    ?>
    <?php if(isset($histories[0])): ?>
        <?php $__currentLoopData = $histories[0]->getModules(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item" role="presentation">
            <a
            class="nav-link <?php echo e($done?'':'active'); ?>"
            id="mod<?php echo e($module->id); ?>"
            data-mdb-toggle="tab"
            href="#mod<?php echo e($module->id); ?>-tab"
            role="tab"
            aria-selected="true"
            ><?php echo e($module->name); ?></a>
            </li>
            <?php
                $done = true;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item" role="presentation">
            <a
            class="nav-link "
            id="all"
            data-mdb-toggle="tab"
            href="#all-tab"
            role="tab"
            aria-selected="true"
            >Résultats Finaux</a>
        </li>
    <?php endif; ?>

  </ul>
  <!-- Tabs navs -->
  <?php
      $done = false;
  ?>
 <div class="tab-content" id="">
    <?php if(isset($histories[0])): ?>

        <?php $__currentLoopData = $histories[0]->getModules(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                class="tab-pane fade <?php echo e($done?'':'show active'); ?>"
                id="mod<?php echo e($module->id); ?>-tab"
                role="tabpanel"
                >
                <?php

                ?>
                <?php echo $__env->make('parts.admin.old.module-result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>


            <?php
                $done = true;
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div
                    class="tab-pane fade "
                    id="all-tab"
                    role="tabpanel"
        >

            <?php echo $__env->make('parts.admin.old.all-result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endif; ?>
</div>
  <!-- Tabs content -->
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\old\results.blade.php ENDPATH**/ ?>