
<?php
    $route = route('tranche.store');
    $target = 'Tranche';
    $adj = 'Une Nouvelle';
    $fields = [
        ['type'=>'text','name'=>'etudiant_cin','value'=>'','label'=>'Le Numéro du CIN de L\'Etudiant'],
        ['type'=>'text','name'=>'vers','value'=>'','label'=>'Le Montant Versé'],
        ['type'=>'text','name'=>'ref','value'=>'','label'=>'Référence du Versement'],
        ['type'=>'date','name'=>'date_vers','value'=> date('d-m-Y'),'label'=>'Date du Versement'],
        ['type'=>'checkbox','name'=>'proved','value'=>'','label'=>'Versement Vérifier'],
    ];

?>
<?php echo $__env->make('parts.admin.common.formulaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/finance/addtranche.blade.php ENDPATH**/ ?>