<!-- Tabs navs -->
<ul class="nav nav-tabs nav-justified mb-3" id="ex1" role="tablist">
    <?php
        $done = false;
    ?>
    <?php $__currentLoopData = $aus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $au => $promos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="nav-item" role="presentation">

      <a
      class="nav-link <?php echo e($done?'':'active'); ?>"
      id="<?php echo e($au); ?>"
      data-mdb-toggle="tab"
      href="#<?php echo e($au); ?>-tab"
      role="tab"
      aria-selected="true"
      ><?php echo e($au); ?></a>
    </li>
    <?php
        $done = true;
    ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </ul>
  <!-- Tabs navs -->
  <?php
      $done = false;
  ?>
  <?php $__currentLoopData = $aus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $au => $promos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="tab-content" id="">
    <div
      class="tab-pane fade <?php echo e($done?'':'show active'); ?>"
      id="<?php echo e($au); ?>-tab"
      role="tabpanel"
    >
        <?php echo $__env->make('parts.admin.old.promo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>


  </div>
    <?php
        $done = true;
    ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <!-- Tabs content -->
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/old/au.blade.php ENDPATH**/ ?>