<script src="/javascript/notes.js"></script>

<div class="row mt-4 ">
    <h2>
        <?php if (! empty(trim($__env->yieldContent('title_ad')))): ?>
            <?php echo $__env->yieldContent('title_ad'); ?>
        <?php else: ?>
            Evaluation des Etudiants
        <?php endif; ?>
    </h2>
</div>
<div class="row mt-1"><hr class="dropdown-divider"></div>
<div class="row ">
    <?php if(isset($errors) && sizeof($errors->all())>0): ?>
    <div class="col p-3 alert alert-danger">
        <ul>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($err); ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
</div>
<div class="row mt-3">
    <p class=" note note-info">Vous devez choisir une formation pour modifier les notes des etudiants.</p>
</div>

<div class="row mt-3 justify-content-center">
    <div class="col-6">
        <select id="formation-select" target="<?php echo $__env->yieldContent('target'); ?>" class="text-reset border col-md-3 p-2 w-100" name="" id="">
            <option disabled selected>Sélectionner une Formation</option>
            <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($form->id); ?>"><?php echo e($form->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

</div>

<div class="border row p-4 mt-4" id="empty-notes">
    <div class="d-flex flex-column justify-content-center align-items-center">

        <p class="text-danger"><i class="fas fa-info  fa-5x"></i></p>
        <p>
            Aucune Donnée à afficher. Veuillez verifier que vous avez sélectionner une formation.
            Si cette zone est toujours vide on vous invite à crée des nouveaux modules , formations, étudiant
        </p>
        <div class="d-flex justify-content-center align-items-center">
            <a href="<?php echo e(route('etudiant.create')); ?>" class="btn btn-secondary m-3"><span class="h6">Ajouter des Etudiants</span></a>
            <a href="<?php echo e(route('formation.create')); ?>" class="btn btn-success m-3"><span class="h6">Ajouter des Formations</span></a>
            <a href="<?php echo e(route('module.create')); ?>" class="btn btn-info m-3"><span class="h6">Ajouter des Modules</span></a>
        </div>
    </div>
</div>


  <!-- Tabs content -->
<div class="row" id="etudiants-notes"></div>
<!-- Tabs content -->
</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\etudiant\evaluation.blade.php ENDPATH**/ ?>