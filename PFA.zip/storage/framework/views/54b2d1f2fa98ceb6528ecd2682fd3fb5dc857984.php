<script type="module" src="/javascript/versement.js"></script>
<div class="row">
    <h2><?php echo $__env->yieldContent("title-list"); ?></h2>
</div>
<div class="row">
    <hr class="dropdown-divider">
</div>
<div class="row ">
    <?php if(isset($errors) && sizeof($errors->all())>0): ?>
    <div class="col p-3 alert alert-danger">
        <ul>

            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <?php echo e($err); ?>

            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>
</div>
<div class="row mt-3 justify-content-center">
    <div class="col-6">
        <select id="formation-select" class="text-reset border col-md-3 p-2 w-100">
            <option value="0">Tous Les Formation</option>
            <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($form->id); ?>"><?php echo e($form->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<div class="row mt-4 justify-content-around">
    <div class="col-sm-4 form-outline">
        <i class="fas fa-search trailing"></i>
        <input type="text" id="search" class="form-control form-icon-trailing" />
        <label class="form-label" for="search">Chercher </label>
    </div>

    <form method="post" id="importForm" action="<?php echo $__env->yieldContent("route-import"); ?>" class="col-sm-7 d-flex justify-content-end "
        enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <a href="<?php echo $__env->yieldContent('route-create'); ?>"
            title="" class="col-1 btn btn-primary btn-floating me-2">
            <i class="fas fa-plus"></i>
        </a>
        <input id="fileInput" type="file" name="file" hidden>
        <button type="button" id="importVersement" title=""
            class="col-1 btn btn-success btn-floating" hidden>
            <i class="fas fa-upload"></i>
        </button>
        <button type="submit" id="submit-import" hidden></button>
        <a href="<?php echo $__env->yieldContent("route-export"); ?>'" id="export"
            title="" class="col-1 btn btn-danger btn-floating ms-2">
            <i class="fas fa-download"></i>
        </a>
        <a href="<?php echo $__env->yieldContent("route-export-empty"); ?>" id="exportEmpty" hidden
            title="" class="col-1 btn btn-dark btn-floating ms-2">
            <i class="fas fa-download"></i>
        </a>
    </form>
</div>
<div class="table-responsive mt-5">
    <table class="table table-bordered table-sm align-middle text-center text-nowrap " id="conten-table">
        <?php echo $__env->yieldContent('table'); ?>
    </table>
</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\common\list-payement-tranche.blade.php ENDPATH**/ ?>