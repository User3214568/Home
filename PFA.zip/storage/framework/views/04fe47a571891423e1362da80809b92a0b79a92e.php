<!-- Tabs navs -->
<script src="/javascript/module-note.js"></script>
<script src="/javascript/notes.js"></script>
<script src="/javascript/evaluation.js"></script>
<ul class="nav nav-tabs nav-pills nav-justified mb-3" id="ex1" role="tablist">
    <?php $done  = false; ?>
    <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(array_key_exists($formation->id, $auth_formations)): ?>
            <li class="nav-item" role="presentation">
                <a class="nav-link <?php echo e($done ? '' : 'active'); ?>" id="<?php echo e($formation); ?>" data-mdb-toggle="tab"
                    href="#tab-<?php echo e(str_replace(' ', '', $formation->name)); ?>" role="tab"
                    aria-selected="true"><?php echo e($formation->name); ?></a>
            </li>
            <?php $done  = true; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>
<!-- Tabs navs -->

<!-- Tabs content -->
<div class="tab-content" id="ex2-content">
    <?php $done  = false; ?>
    <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(array_key_exists($formation->id, $auth_formations)): ?>
            <?php
                $auth_modules = $auth_formations[$formation->id]
            ?>
            <div class="tab-pane fade <?php echo e($done ? '' : 'show active'); ?>" id="tab-<?php echo e(str_replace(' ', '', $formation)); ?>"
                role="tabpanel">
                <?php echo $__env->make('parts.enseignant.notes.notesv2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <?php $done  = true; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<!-- Tabs content -->
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\enseignant\notes\notes.blade.php ENDPATH**/ ?>