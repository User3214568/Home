<table class="table table-bordered  align-middle">
    <?php $count_columns = 0; ?>
    <thead>

        <tr>
            <td></td>
            <th>CIN</th>
            <th>Nom et Prénom</th>
            <th>Note Final</th>
            <th>Résultat Final</th>

        </tr>
    </thead>
    <tbody>

        <?php if(sizeof($sem->promotion->etudiants) > 0): ?>
            <?php $counter = 0; ?>
            <?php $__currentLoopData = $sem->promotion->etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($etudiant->hasSession($mymodule->id,$session)): ?>
                    <?php $counter++; ?>
                    <tr>
                        <th><?php echo e($key + 1); ?></th>
                        <th scope="row"><?php echo e($etudiant->user->cin); ?></th>
                        <th scope="row"><?php echo e($etudiant->user->name()); ?></th>
                        <?php if(sizeof($mymodule->devoirs) > 0): ?>
                            <?php
                                if($session == 1){
                                    $note = App\Utilities\Validation::validateSessionModule($etudiant->cin,$mymodule->id,$session,false);
                                }else{
                                    $note = App\Utilities\Validation::FinalModuleNote($etudiant->cin,$mymodule->id);
                                }
                            ?>
                            <th scope="row"><?php echo e($note); ?></th>
                            <td><?php echo e(App\Utilities\Validation::resultDesc($etudiant->formation,$note,$session == 1 ? 1:0)); ?></td>
                        <?php else: ?>
                            <td>Aucune Note</td>
                        <?php endif; ?>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($counter == 0 && $session == 2): ?>
                <td colspan="<?php echo e(5); ?>">Aucun Etudiant Rattrapant. Veuillez verifier que vous avez Valider
                les notes du session Ordinaire.</td>
            <?php endif; ?>
        <?php else: ?>
            <td colspan="5">Aucun Etudiant appartient à cette Promotion</td>
        <?php endif; ?>

    </tbody>
</table>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/etudiant/result-table.blade.php ENDPATH**/ ?>