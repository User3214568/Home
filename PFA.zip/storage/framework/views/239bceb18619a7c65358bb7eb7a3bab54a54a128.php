<script type="module" src="/javascript/list-etudiants.js"></script>

<?php $__env->startSection('title-list', 'List des Etudiants'); ?>
<?php $__env->startSection('route-import', route('etudiant.import', ['id' => 0])); ?>
<?php $__env->startSection('route-create', route('etudiant.create')); ?>
<?php $__env->startSection('route-export-empty', route('etudiant.export', ['id' => 0, 'type' => 'true'])); ?>
<?php $__env->startSection('route-export', route('etudiant.export', ['id' => 0, 'type' => 'false'])); ?>
<?php $__env->startSection('table'); ?>
    <tr>
        <th>Formation</th>
        <th>Nom</th>
        <th>Prénom</th>
        <th>CIN</th>
        <th>Promotion</th>
        <th>Actions</th>
    </tr>
    <?php $count = false ; ?>
    <?php $__currentLoopData = $etudiants->sortBy('formation_id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($etudiant->promotion): ?>
            <?php
                if (!$count) {
                    $count = true;
                }
            ?>
            <tr name="versement">
                <td><?php echo e($etudiant->formation->name); ?></td>
                <td><?php echo e($etudiant->user->first_name); ?></td>
                <td><?php echo e($etudiant->user->last_name); ?></td>
                <td><?php echo e($etudiant->user->cin); ?></td>
                <td><?php echo e($etudiant->promotion ? $etudiant->promotion->nom : 'Sans Promotion'); ?></td>
                <td class="d-flex justify-content-center  align-items-center">
                    <form action="<?php echo e(route('etudiant.destroy', ['etudiant' => $etudiant->cin])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-outline-danger btn-floating">
                            <i class="fas fa-times  fa-1x"></i>
                        </button>
                    </form>
                    <form action="<?php echo e(route('etudiant.edit', ['etudiant' => $etudiant->cin])); ?>" method="GET">
                        <button class="btn btn-outline-secondary ms-1 btn-floating">
                            <i class="fas fa-pen-fancy fa-1x"></i>
                        </button>
                    </form>
            </tr>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(!$count): ?>
        <tr>
            <td colspan="6">Aucun Etudiant à afficher.</td>
        </tr>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('parts.admin.common.list-payement-tranche', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\etudiant\list.blade.php ENDPATH**/ ?>