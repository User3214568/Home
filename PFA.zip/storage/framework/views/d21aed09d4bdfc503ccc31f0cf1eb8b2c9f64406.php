<table class="table table-bordered mt-3 align-middle">
    <?php $count_columns = 0; ?>
    <thead>
        <tr>

            <?php if(!isset($auth_modules) || (isset($auth_modules) && in_array($mymodule->id,$auth_modules))): ?>
            <td rowspan="1"></td>
            <?php $__currentLoopData = $mymodule->devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devoir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($devoir->session == $session): ?>
                    <th>
                        <?php echo e($devoir->name); ?>

                        <?php
                            $count_columns++;
                        ?>
                    </th>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                    <td>Vous n'etes pas autoriser d'acceder a ce contenu.</td>
            <?php endif; ?>
        </tr>
    </thead>
    <tbody>
        <?php $empty_set = 0; ?>
        <?php if(!isset($auth_modules) || (isset($auth_modules) && in_array($mymodule->id,$auth_modules))): ?>

        <?php if(sizeof($sem->promotion->etudiants) > 0): ?>
            <?php $__currentLoopData = $sem->promotion->etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($etudiant->hasSession($mymodule->id, $session)): ?>
                    <?php $empty_set++; ?>
                    <tr>
                        <th scope="row"><?php echo e($etudiant->user->name()); ?></th>
                        <?php if(sizeof($mymodule->devoirs) > 0): ?>
                            <?php $__currentLoopData = $mymodule->devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devoir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($devoir->session == $session): ?>
                                    <?php $evaluation = $etudiant->evaluations->where('devoir_id', $devoir->id)->first(); ?>
                                    <?php if($evaluation): ?>
                                        <td class="border" name="note" id="<?php echo e($evaluation->id); ?>"
                                            contenteditable="true">
                                            <?php echo e($evaluation->note ?: 0); ?>

                                        </td>
                                    <?php endif; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <td>Aucune Note</td>
                        <?php endif; ?>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <?php
                $empty_set = 1;
            ?>
            <td colspan="<?php echo e($count_columns + 1); ?>">Aucun Etudiant appartient à cette Promotion</td>
        <?php endif; ?>
        <?php if($empty_set == 0 && $session == 2): ?>
            <td colspan="<?php echo e(sizeof($mymodule->devoirs)+1); ?>">Aucun Etudiant Rattrapant. Veuillez verifier que vous avez Valider
                les notes du session Ordinaire.</td>
        <?php endif; ?>
        <?php if($empty_set == 0 && $session == 1): ?>
            <td colspan="<?php echo e(sizeof($mymodule->devoirs)+1); ?>">Aucun Etudiant n'est inscrit dans la session ordinaire de ce Module.</td>
        <?php endif; ?>
        <?php endif; ?>
    </tbody>
</table>
<?php if(!isset($result)): ?>
    <div class="row justify-content-around p-3">

    </div>
<?php endif; ?>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/etudiant/table-module-note.blade.php ENDPATH**/ ?>