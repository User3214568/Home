<div class="row">
    <h2>Mes Versements</h2>
    <hr class="dropdown-divider">
</div>
<?php $total = 0 ; ?>
<table class="table table-border mt-3">
    <tr>
        <th>Réference du versement</th>
        <th>Etat du Versement</th>
        <th>Montant Versé</th>
        <th>Date Versement</th>
    </tr>
    <?php if(sizeof($versements)>0): ?>
        <?php $__currentLoopData = $versements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $versement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="<?php echo e($versement->proved?'text-success':'text-danger'); ?>">
            <td><?php echo e($versement->ref); ?></td>
            <td><?php echo e($versement->proved?'Verifié':'Non Vérifier'); ?></td>
            <td><?php echo e($versement->vers); ?></td>
            <td><?php echo e($versement->date_vers); ?></td>
            <?php
                $total += $versement->vers;
            ?>
        </tr>
        <tr class="<?php echo e(($etudiant->formation->prix - $total) > 0 ? 'bg-danger':'bg-success'); ?>">
            <th>Total Versé</th>
            <th><?php echo e($total); ?></th>
            <th>Restant</th>
            <th><?php echo e($etudiant->formation->prix - $total); ?></th>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <tr>
            <td colspan="4">
                Vous n'avez effectué aucun versement.
            </td>
        </tr>
    <?php endif; ?>
</table>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/etudiant/versements.blade.php ENDPATH**/ ?>