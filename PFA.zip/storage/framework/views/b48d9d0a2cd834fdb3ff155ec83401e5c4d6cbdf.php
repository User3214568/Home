<?php $__env->startSection('title'); ?>
    Gestionnaire de Formation | Gestion Pédagogique et Financiére
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('parts.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $error = " Un Problème lié a notre base de données à ete survenu.
"?>
<?php echo $__env->make('parts.admin.common.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('parts.layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Home\resources\views\error-db-off.blade.php ENDPATH**/ ?>