<?php $__env->startSection('title'); ?>
    Gestionnaire de Formation | Gestion Pédagogique et Financiére
<?php $__env->stopSection(); ?>

<?php
    $items = [
        ['title'=>'Acceuil','link'=> route('etudiant.home'), 'icon'=>'fas fa-home', 'expanded'=>false ],
        ['title'=>'Mes Résultats','link'=>route('etudiant.resultspage'), 'icon'=>'fas fa-code-branch', 'expanded'=>false],
        ['title'=>'Mes Versements','link'=>route('etudiant.versements') , 'icon'=>'fas fa-th', 'expanded'=>false],
    ];
?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('parts.layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('parts.etudiant.content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('parts.layout.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Home\resources\views\etudiant.blade.php ENDPATH**/ ?>