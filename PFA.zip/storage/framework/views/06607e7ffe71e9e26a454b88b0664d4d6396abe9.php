<div class="border  col-md-3  card text-center m-4">
    <div class="card-body">
    <div class="card-header text-muted"><?php echo e(App\Utilities\Calculation::time_diff($formation->updated_at)); ?></div>
    <h5 class="card-title"><?php echo e($formation->name); ?></h5>
    <p class=" card-text">
       <?php echo e($formation->description); ?>

    </p>
    <hr class="dropdown-divider">
    <div class="card-text row">
        <?php $__currentLoopData = $formation->semestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $sem->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="col m-1 card-formation-module"><?php echo e($module->name); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
    <div class="card-footer text-muted">
        <a class="btn btn-success btn-lg btn-floating" href="<?php echo e(route('formation.edit',$formation->id)); ?>">
            <i class="fas fa-pen-nib"></i>
        </a>
        <form class="d-inline" method="post" action="<?php echo e(route('formation.destroy',$formation)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button  class="btn btn-danger btn-lg btn-floating" data-mdb-ripple-color="dark">
                <i class="fas fa-trash-alt"></i>
            </button>
        </form>
    </div>
</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\formation\formation-card.blade.php ENDPATH**/ ?>