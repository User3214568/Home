<?php
    $target = 'module'
?>
<?php echo $__env->make('parts.admin.common.mod-form-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/module/index.blade.php ENDPATH**/ ?>