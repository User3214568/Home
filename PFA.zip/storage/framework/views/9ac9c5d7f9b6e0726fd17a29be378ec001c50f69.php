<script type="module" src="/javascript/list-versement.js"></script>

<?php $__env->startSection('title-list','Versements des Etudiants'); ?>
<?php $__env->startSection('route-import',route('finance.import.versement')); ?>
<?php $__env->startSection('route-create',route('tranche.create')); ?>
<?php $__env->startSection('route-export',route('finance.export.formation', ['id' => 0, 'type' => 'false'])); ?>
<?php $__env->startSection('route-export-empty',route('finance.export.formation', ['id' => 0, 'type' => 'true'])); ?>
<?php $__env->startSection('table'); ?>
<?php if(sizeof($etudiants)>0): ?>
    <tr class="">
        <th rowspan="3">Formation</th>
        <th rowspan="3">Nom</th>
        <th rowspan="3">Prénom</th>
        <th rowspan="3">CIN</th>
        <th colspan="16">Versements</th>
        <th rowspan="3">Total Versé</th>
        <th rowspan="3">Rest</th>
    </tr>
    <tr>
        <th colspan="4">Versement 1</th>
        <th colspan="4">Versement 2</th>
        <th colspan="4">Versement 3</th>
        <th colspan="4">Versement 4</th>
    </tr>
    <tr>
        <th>Montant</th>
        <th>Référence</th>
        <th>Date</th>
        <th></th>
        <th>Montant</th>
        <th>Référence</th>
        <th>Date</th>
        <th></th>
        <th>Montant</th>
        <th>Référence</th>
        <th>Date</th>
        <th></th>
        <th>Montant</th>
        <th>Référence</th>
        <th>Date</th>
        <th></th>
    </tr>
    <?php $__currentLoopData = $etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr name="versement">
            <td><?php echo e($etudiant->formation->name); ?></td>
            <td><?php echo e($etudiant->user->first_name); ?></td>
            <td><?php echo e($etudiant->user->last_name); ?></td>
            <td><?php echo e($etudiant->user->cin); ?></td>
            <?php $sum = 0; ?>
            <?php $__currentLoopData = $etudiant->tranches->sortBy('date_vers'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tranche): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <td class="<?php echo e($tranche->proved ? 'text-success' : 'text-danger'); ?>"><?php echo e($tranche->vers); ?></td>
                <td class="<?php echo e($tranche->proved ? 'text-success' : 'text-danger'); ?>"><?php echo e($tranche->ref); ?></td>
                <td class="<?php echo e($tranche->proved ? 'text-success' : 'text-danger'); ?>"><?php echo e($tranche->date_vers); ?></td>
                <td class="d-flex justify-content-center  align-items-center">
                    <form action="<?php echo e(route('tranche.destroy',['tranche'=>$tranche->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>
                        <button class="btn btn-outline-danger btn-floating">
                            <i class="fas fa-times  fa-1x"></i>
                        </button>
                    </form>
                    <form action="<?php echo e(route('tranche.edit',['tranche'=>$tranche->id])); ?>" method="GET">
                        <button class="btn btn-outline-secondary ms-1 btn-floating">
                            <i class="fas fa-pen-fancy fa-1x"></i>
                        </button>
                    </form>
                </td>
                <?php $sum += $tranche->vers; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php for($i = sizeof($etudiant->tranches); $i < 4; $i++): ?>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
            <?php endfor; ?>
            <td><?php echo e($sum); ?></td>
            <td><?php echo e($etudiant->formation->prix - $sum); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <tr>
        <td colspan="21" class="text-left">Aucun Etudiants à afficher.</td>
    </tr>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('parts.admin.common.list-payement-tranche', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/finance/list-vers.blade.php ENDPATH**/ ?>