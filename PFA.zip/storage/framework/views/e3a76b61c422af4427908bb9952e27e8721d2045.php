<table class="table table-bordered  align-middle">
    <?php $count_columns = 0; ?>
    <thead>
        <tr>
            <td rowspan="1"></td>
            <th>CIN</th>
            <th>Nom et Prénom</th>
            <th>Note Moyenne</th>
            <th>Résultat</th>
        </tr>
    </thead>
    <tbody>
        <?php $counter = 0; ?>
        <?php if(sizeof($sem->promotion->etudiants) > 0): ?>
            <?php $__currentLoopData = $sem->promotion->etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($etudiant->hasSessionSemestre($sem->id,$session)): ?>
                    <?php $counter++; ?>
                    <tr>
                        <th><?php echo e($key + 1); ?></th>
                        <th scope="row"><?php echo e($etudiant->user->cin); ?></th>
                        <th scope="row"><?php echo e($etudiant->user->name()); ?></th>
                        <?php $glob_note = 0; ?>
                        <?php $__currentLoopData = $sem->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mymodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(sizeof($mymodule->devoirs) > 0): ?>
                                <?php
                                if($session == 1){
                                    $note = App\Utilities\Validation::validateSessionModule($etudiant->cin,$mymodule->id,1,false);

                                }else $note = App\Utilities\Validation::FinalModuleNote($etudiant->cin,$mymodule->id);
                                ?>
                                <?php $glob_note += $note; ?>
                            <?php else: ?>
                                <td>Aucune Note</td>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            if(sizeof($sem->modules) > 0 ){
                                    $glob_note = number_format($glob_note / sizeof($sem->modules),2);
                            }else{
                                $glob_note  = 0;
                            }
                        ?>
                        <td><?php echo e(sizeof($sem->modules) > 0 ? $glob_note : '-'); ?></td>
                        <td><?php echo e($glob_note >= $etudiant->formation->critere->note_validation ? 'Validé' : ($glob_note >= $etudiant->formation->critere->note_aj ? 'Non Validé' : 'Ajourné')); ?></td>

                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($counter == 0 && $session == 1): ?>
                <td colspan="<?php echo e(5); ?>">Cette Semestre ne contient aucun module.</td>
            <?php endif; ?>
            <?php if($counter == 0 && $session == 2): ?>
                <td colspan="<?php echo e(5); ?>">Aucun Etudiant Rattrapant. Veuillez verifier que vous avez Valider
                les notes du session Ordinaire.</td>
            <?php endif; ?>
        <?php else: ?>
            <td colspan="<?php echo e(5); ?>">Aucun Etudiant appartient à cette Promotion</td>
        <?php endif; ?>

    </tbody>
</table>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/etudiant/semestre-result.blade.php ENDPATH**/ ?>