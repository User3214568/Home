<div class="row m-1 justify-content-between" >
    <?php echo $__env->make('parts.admin.dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-md-9 " id="admin-content">

        <?php if(!isset($content)): ?>

        <?php else: ?>
        <?php switch($content):

        case ('admin.home'): ?>
        <?php echo $__env->make('parts.admin.dashboard.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('formation.create'): ?>
        <?php echo $__env->make('parts.admin.formation.formation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('formation.update'): ?>
        <?php echo $__env->make('parts.admin.formation.formation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('formation.index'): ?>
        <?php echo $__env->make('parts.admin.formation.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('module.create'): ?>
            <?php echo $__env->make('parts.admin.module.module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('module.update'): ?>
        <?php echo $__env->make('parts.admin.module.module', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('module.index'): ?>
        <?php echo $__env->make('parts.admin.module.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('etudiant.create'): ?>
        <?php echo $__env->make('parts.admin.etudiant.etudiant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('etudiant.update'): ?>
        <?php echo $__env->make('parts.admin.etudiant.etudiant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('etudiant.index'): ?>
        <?php echo $__env->make('parts.admin.etudiant.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('etudiant.evaluation'): ?>
        <?php echo $__env->make('parts.admin.etudiant.evaluation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('etudiant.result'): ?>
        <?php echo $__env->make('parts.admin.etudiant.resultat', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('user.create'): ?>
        <?php echo $__env->make('parts.admin.user.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('user.update'): ?>
        <?php echo $__env->make('parts.admin.user.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('user.index'): ?>
        <?php echo $__env->make('parts.admin.user.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>


        <?php case ('finance.add.tranche'): ?>
        <?php echo $__env->make('parts.admin.finance.addtranche', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('finance.tranche.edit'): ?>
        <?php echo $__env->make('parts.admin.finance.edit-tranche', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('finance.add.payement'): ?>
        <?php echo $__env->make('parts.admin.finance.profpay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('finance.payement.update'): ?>
        <?php echo $__env->make('parts.admin.finance.profpay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('finance.payement.consultants'): ?>
        <?php echo $__env->make('parts.admin.finance.consultantspay', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('finance.versemnt.list'): ?>
        <?php echo $__env->make('parts.admin.finance.list-vers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('professeur.create'): ?>
        <?php echo $__env->make('parts.admin.Professeur.add-prof', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('professeur.update'): ?>
        <?php echo $__env->make('parts.admin.Professeur.edit-prof', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('list-prof'): ?>
        <?php echo $__env->make('parts.admin.Professeur.list-prof', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('depense.list'): ?>
        <?php echo $__env->make('parts.admin.common.depense.list-dep', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>;

        <?php case ('depense.add'): ?>
        <?php echo $__env->make('parts.admin.common.depense.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>;

        <?php case ('dep.update'): ?>
        <?php echo $__env->make('parts.admin.common.depense.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>;

        <?php case ('etudiant.imported'): ?>
        <?php echo $__env->make('parts.admin.etudiant.imported-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('etudiant.delibration'): ?>
        <?php echo $__env->make('parts.admin.etudiant.delibration', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('teacher.index'): ?>
        <?php echo $__env->make('parts.admin.teacher.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>
        <?php case ('teacher.create'): ?>
        <?php echo $__env->make('parts.admin.teacher.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('old.index'): ?>
        <?php echo $__env->make('parts.admin.old.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php case ('formations.laureat'): ?>
        <?php echo $__env->make('parts.admin.laureats.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php break; ?>

        <?php default: ?>

        <?php endswitch; ?>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\dashboard\admin-content.blade.php ENDPATH**/ ?>