<div class="table-responsive">

    <table class="table align-middle  text-nowrap">
        <tr>
            <th>CIN</th>
            <th>Nom et Prénom</th>
            <th>Note Finale</th>
            <th>Résultat Finale</th>
        </tr>

        <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($history->etudiant)): ?>
        <tr>
            <td><?php echo e($history->etudiant_cin); ?></td>
            <td><?php echo e($history->etudiant->name()); ?></td>
            <td>
                    <?php
                    $result =  $history->hisresults->where('module_id',$module->id)->first()->note_final;


                    ?>
               <?php echo e(number_format($result,2)); ?>

            </td>
            <td>
                <?php echo e(\App\Utilities\Validation::resultDesc($history->etudiant->formation,$result)); ?>

            </td>
        </tr>
        <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\old\module-result.blade.php ENDPATH**/ ?>