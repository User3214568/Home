<table class="table">
    <tr>
        <td>CIN</td>
        <td>Nom et Prénom</td>
        <?php $__currentLoopData = $profs[0]->module->devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($dev->session == $session): ?>
                <td><?php echo e($dev->name); ?></td>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    <?php
        $promo = $profs[0]->findPromotion();
        $count = 0;
    ?>
    <?php if($promo): ?>
        <?php $__currentLoopData = $promo->etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($e->hasSession($profs[0]->module->id, $session)): ?>
                <tr>
                    <td><?php echo e($e->cin); ?></td>
                    <td><?php echo e($e->name()); ?></td>
                    <?php $__currentLoopData = $profs[0]->module->devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($dev->session == $session): ?>
                            <?php
                                $eval = $e->evaluations
                                    ->where('etudiant_cin', $e->cin)
                                    ->where('devoir_id', $dev->id)
                                    ->first();
                            ?>
                            <?php if($eval): ?>
                                <td><?php echo e($eval->note ?: 0); ?></td>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <?php
                    $count++;
                ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($count == 0): ?>
                <tr><td>Aucun Rattrapant</td></tr>
        <?php endif; ?>
    <?php else: ?>
        <tr><td>Aucun Etudiant</td></tr>
    <?php endif; ?>
</table>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\enseignant\notes\notes-table.blade.php ENDPATH**/ ?>