<div class="row">
    <h2>Vos <?php echo e(ucwords($target)."s"); ?></h2>
</div>
<div class="row justify-content-center">
    <div class="dropdown-divider"></div>
    <div class="border  col-md-3   card text-center m-md-4">
        <div class="card-body ">
        <a class="card-text text-primary" href="<?php echo e(route("$target".'.create')); ?>">
            <i class="fas fa-plus fa-9x"></i>
        </a>
        <p>Ajouter un<?php echo e(isset($formations)?'e Nouvelle ':' Nouveau '); ?> <?php echo e(ucwords($target)); ?></p>
        </div>
    </div>
    <?php if(isset($formations) && sizeof($formations) > 0 ): ?>
        <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $name = $formation->name;
              $description = $formation->description;
              $target = 'formation';
              $id = $formation->id
        ?>
            <?php echo $__env->make('parts.admin.formation.formation-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php elseif( isset($modules) && sizeof($modules)>0): ?>
        <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $name = $module->name;
              $description = $module->description;
              $target = 'module';
              $passed = \App\Utilities\Calculation::time_diff($module->updated_at);
              $id = $module->id;
        ?>
            <?php echo $__env->make('parts.admin.common.card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="text-reset text-center">Aucun<?php echo e(isset($formations)?'e formation':' module'); ?> n'existe pour le moment. Essayer d'ajouter des <?php echo e(isset($formations)?' nouvelles formations':' nouveaux modules'); ?></div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/common/mod-form-index.blade.php ENDPATH**/ ?>