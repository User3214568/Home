<div class="row">
    <!-- Tabs navs -->
    <ul class="nav nav-tabs nav-justified mb-3" id="ex1" role="tablist">
        <?php $done = false; ?>
        <?php $__currentLoopData = $promotion->semestres->sortBy('numero'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $semestre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li  name="triggers-semestre" class="nav-item" role="presentation">
                <a class="nav-link <?php echo e($done ? ' ' : 'active'); ?>" <?php $done = true; ?>
                    id="tab-<?php echo e($semestre->numero . '-' . $promotion->numero); ?>" data-mdb-toggle="tab"
                    href="#tabs-<?php echo e($semestre->numero . '-' . $promotion->numero); ?>" role="tab"
                    aria-controls="tabs-<?php echo e($semestre->numero . '-' . $promotion->numero); ?>"
                    aria-selected="true"><?php echo e('Semestre ' . $semestre->numero); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <!-- Tabs navs -->

    <div class="tab-content" id="content">
        <?php if(sizeof($promotion->semestres) > 0): ?>
        <?php $done = false; $render = true; ?>
            <?php $__currentLoopData = $promotion->semestres->sortBy('numero'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class=" tab-pane fade <?php echo e(( $done ? ' ' : 'show active')); ?>"
                    id="tabs-<?php echo e($sem->numero . '-' . $promotion->numero); ?>" role="tabpanel"
                    aria-labelledby="tab-<?php echo e($sem->numero . '-' . $promotion->numero); ?>">
                    <!-- Tabs navs -->
                    <?php $done = true; ?>
                    <ul class="nav nav-tabs mb-3" id="ex1" role="tablist">
                        <li  name="triggers" class="nav-item" role="presentation">
                            <a class="nav-link active" id="<?php echo e($sem->id . '-' . $promotion->numero); ?>-modules-all"
                                data-mdb-toggle="tab" href="#tab-<?php echo e($sem->id . '-' . $promotion->numero); ?>-modules-all"
                                role="tab" aria-controls="ex1-tabs-1"
                                aria-selected="true"><?php echo e(isset($result) ? 'Résultat du Semestre' : 'Tous Les Modules'); ?></a>
                        </li>
                        <?php $__currentLoopData = $sem->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!isset($auth_modules) || (isset($auth_modules) && in_array($module->id,$auth_modules))): ?>
                            <li  name="triggers" class="nav-item tab-item" role="presentation">
                                <a class="nav-link "
                                    id="<?php echo e($sem->id . '-' . $promotion->numero . '-' . $module->id); ?>"
                                    data-mdb-toggle="tab"
                                    href="#tab-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $module->id); ?>" role="tab"
                                    aria-controls="ex1-tabs-1" aria-selected="true"><?php echo e($module->name); ?></a>
                            </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <!-- Tabs navs -->
                    <div class="tab-content" id="ex1-content">
                        <div class="tab-pane fade show active"
                            id="tab-<?php echo e($sem->id . '-' . $promotion->numero); ?>-modules-all" role="tabpanel"
                            aria-labelledby="ex1-tab-1">

                            <!--  TABS FOR ALL MODULES  -->
                            <!-- Tabs navs -->
                            <ul class="nav nav-tabs mb-3" id="ex1" role="tablist">
                                <li  name="triggers-session" class="nav-item" role="presentation">
                                    <a class="nav-link active" id="ord-<?php echo e($sem->id . '-' . $promotion->numero); ?>"
                                        data-mdb-toggle="tab" href="#tab-ord-<?php echo e($sem->id . '-' . $promotion->numero); ?>"
                                        role="tab" aria-controls="tab-ord-<?php echo e($sem->id . '-' . $promotion->numero); ?>"
                                        aria-selected="true">Session
                                        Ordinaire</a>
                                </li>
                                <li  name="triggers-session" class="nav-item" role="presentation">
                                    <a class="nav-link" id="rat-<?php echo e($sem->id . '-' . $promotion->numero); ?>"
                                        data-mdb-toggle="tab" href="#tab-rat-<?php echo e($sem->id . '-' . $promotion->numero); ?>"
                                        role="tab" aria-controls="" aria-selected="false">Session Rattrappage</a>
                                </li>

                            </ul>
                            <!-- Tabs navs -->

                            <!-- Tabs content -->
                            <div class="tab-content" id="ex1-content">

                                <div name="notes" semestre="<?php echo e($sem->id); ?>" session="1" result="<?php echo e(isset($result)?'true':'false'); ?>" promotion="<?php echo e($promotion->id); ?>" class="tab-pane fade show active"
                                    id="tab-ord-<?php echo e($sem->id . '-' . $promotion->numero); ?>" role="tabpanel"
                                    aria-labelledby="ord-<?php echo e($sem->id . '-' . $promotion->numero); ?>">
                                    <?php $session = 1; ?>
                                    <?php if(!isset($result)): ?>
                                        <div class="row justify-content-end">
                                            <button onclick="save(this)" name="savenote"
                                                title="Enregistrer les modifications"
                                                class="me-2 btn btn-success btn-floating">
                                                <i class="fas fa-save"></i>
                                            </button>
                                            <?php if(!isset($auth_modules)): ?>
                                                <a title="Commiter Les Notes du Session Ordinaire" name="commitOrd"
                                                    href="<?php echo e(route('module.commit.notes', ['promotion_id' => $promotion->id, 'sem_id' => $sem->id, 'module_id' => 0])); ?>"
                                                    class="btn btn-primary btn-floating  ms-2">
                                                    <i class="fas fa-check"></i>
                                                </a>
                                            <?php endif; ?>
                                        </div>
                                        <div class="table-responsive mt-2">
                                            <?php if($render): ?>
                                                <?php echo $__env->make('parts.admin.etudiant.tablenote', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>

                                        <div class="table-responsive mt-2">
                                            <?php if($render): ?>
                                                <?php echo $__env->make('parts.admin.etudiant.semestre-result', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php $render = false;  ?>
                                </div>
                                <div name="notes" semestre="<?php echo e($sem->id); ?>" session="2" result="<?php echo e(isset($result)?'true':'false'); ?>" promotion="<?php echo e($promotion->id); ?>" class="tab-pane fade" id="tab-rat-<?php echo e($sem->id . '-' . $promotion->numero); ?>"
                                    role="tabpanel" aria-labelledby="ex1-tab-2">
                                    <?php $session = 2; ?>
                                    <?php if(!isset($result)): ?>
                                        <div class="row justify-content-end">
                                            <button onclick="save(this)" name="savenote"
                                                title="Enregistrer les modifications"
                                                class="me-2 btn btn-success btn-floating">
                                                <i class="fas fa-save"></i>
                                            </button>

                                        </div>
                                        <div class="table-responsive mt-2">
                                            <!-- ('parts.admin.etudiant.tablenote') -->
                                        </div>
                                    <?php else: ?>
                                        <div class="table-responsive mt-2">
                                            <!--('parts.admin.etudiant.semestre-result')-->
                                        </div>
                                    <?php endif; ?>

                                </div>

                            </div>
                            <!-- Tabs content -->

                        </div>
                        <?php $showModule = false; ?>
                        <?php $__currentLoopData = $sem->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mymodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!isset($auth_modules) || (isset($auth_modules) && in_array($mymodule->id,$auth_modules))): ?>

                            <div class="tab-pane fade"
                                id="tab-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $mymodule->id); ?>" role="tabpanel"
                                aria-labelledby="ex1-tab-2">
                                <ul class="nav nav-tabs mb-3" id="ex1" role="tablist">
                                    <li  name="triggers-session-module" class="nav-item" role="presentation">
                                        <a class="nav-link active"
                                            id="sord-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $mymodule->id); ?>"
                                            data-mdb-toggle="tab"
                                            href="#tab-sord-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $mymodule->id); ?>"
                                            role="tab"
                                            aria-controls="sord-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $mymodule->id); ?>"
                                            aria-selected="true">Session Ordinaire</a>
                                    </li>
                                    <li  name="triggers-session-module" class="nav-item" role="presentation">
                                        <a class="nav-link"
                                            id="srat-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $mymodule->id); ?>"
                                            data-mdb-toggle="tab"
                                            href="#tab-srat-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $mymodule->id); ?>"
                                            role="tab"
                                            aria-controls="tab-srat-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $mymodule->id); ?>"
                                            aria-selected="false">Session Rattrappage</a>
                                    </li>

                                </ul>
                                <!-- Tabs navs -->

                                <!-- Tabs content -->

                                <div class="tab-content p-2" id="ex1-content">
                                    <div name="notes-module" session="1" module="<?php echo e($mymodule->id); ?>" semestre="<?php echo e($sem->id); ?>" result="<?php echo e(isset($result)?'true':'false'); ?>" promotion="<?php echo e($promotion->id); ?>" class="tab-pane fade show active"
                                        id="tab-sord-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $mymodule->id); ?>"
                                        role="tabpanel"
                                        aria-labelledby="tab-sord-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $mymodule->id); ?>">
                                        <div class="row justify-content-end">
                                            <?php if(!isset($result)): ?>
                                                <form class="row justify-content-end"
                                                    action="<?php echo e(route('etudiant.notes.import', ['sem_id' => $sem->id, 'module_id' => $mymodule->id, 'session' => 1])); ?>"
                                                    method="post" enctype="multipart/form-data">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="button" name="importModule"
                                                        title="Importer Les Notes du Module"
                                                        class="btn btn-success btn-floating ">
                                                        <i class="fas fa-upload"></i>

                                                    </button>
                                                    <input name="file" type="file" hidden>
                                                    <a title="Exporter Les Notes du Module" name="exportModule"
                                                        href="<?php echo e(route('etudiant.notes.module.export', ['sem_id' => $sem->id, 'module_id' => $mymodule->id, 'session' => 1, 'type' => 'false'])); ?>"
                                                        class="btn btn-danger btn-floating ms-2">
                                                        <i class="fas fa-download"></i>

                                                    </a>
                                                    <a title="Commiter Les Notes du Session Ordinaire" name="commitOrd"
                                                        href="<?php echo e(route('module.commit.notes', ['promotion_id' => $promotion->id, 'sem_id' => $sem->id, 'module_id' => $mymodule->id])); ?>"
                                                        class="btn btn-primary btn-floating  ms-2">
                                                        <i class="fas fa-check"></i>
                                                    </a>
                                                    <button type="button" onclick="save(this)" name="savenote"
                                                        title="Enregistrer les modifications"
                                                        class="btn btn-success btn-floating  ms-2">
                                                        <i class="fas fa-save"></i>
                                                    </button>
                                                    <button type="submit" id="submit" hidden></button>

                                                </form>
                                            <?php else: ?>
                                            <div class="row justify-content-end ">
                                                <a title="Exporter les Résultat" href="<?php echo e(route('export.resultat.modules',['promotion_id'=>$promotion->id,'module_id'=>$mymodule->id,"session"=>1])); ?>" class="btn btn-danger btn-floating">
                                                    <i class="fas fa-file-export"></i>
                                                </a>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="table-responsive mt-2">
                                            <?php $session = 1; ?>
                                            <?php if(!isset($result)): ?>
                                                <?php if($showModule): ?>
                                                    <?php echo $__env->make('parts.admin.etudiant.table-module-note', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if($showModule): ?>
                                                    <?php echo $__env->make('parts.admin.etudiant.result-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php $showModule = false; ?>
                                        </div>
                                    </div>
                                    <div name="notes-module" session="2"  module="<?php echo e($mymodule->id); ?>" semestre="<?php echo e($sem->id); ?>" result="<?php echo e(isset($result)?'true':'false'); ?>" promotion="<?php echo e($promotion->id); ?>" class=" tab-pane fade"
                                        id="tab-srat-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $mymodule->id); ?>"
                                        role="tabpanel"
                                        aria-labelledby="srat-<?php echo e($sem->id . '-' . $promotion->numero . '-' . $mymodule->id); ?>">
                                        <?php if(!isset($result)): ?>
                                            <form class="row justify-content-end"
                                                action="<?php echo e(route('etudiant.notes.import', ['sem_id' => $sem->id, 'module_id' => $mymodule->id, 'session' => 2])); ?>"
                                                method="post" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <button type="button" name="importModule"
                                                    title="Importer Les Notes du Module"
                                                    class="btn btn-success btn-floating">
                                                    <i class="fas fa-upload"></i>
                                                </button>
                                                <input name="file" type="file" hidden>
                                                <a title="Exporter Les Notes du Module" name="exportModule"
                                                    href="<?php echo e(route('etudiant.notes.module.export', ['sem_id' => $sem->id, 'module_id' => $mymodule->id, 'session' => 2, 'type' => 'false'])); ?>"
                                                    class="btn btn-danger btn-floating ms-2">
                                                    <i class="fas fa-download fa-1x"></i>
                                                </a>
                                                <button type="button" name="savenote"
                                                    title="Enregistrer les modifications"
                                                    class="btn btn-success btn-floating  ms-2">
                                                    <i class="fas fa-save"></i>
                                                </button>
                                                <button type="submit" id="submit" hidden></button>
                                            </form>
                                        <?php else: ?>
                                        <div class="row justify-content-end ">
                                            <a title="Exporter les Résultat" href="<?php echo e(route('export.resultat.modules',['promotion_id'=>$promotion->id,'module_id'=>$mymodule->id,"session"=>2])); ?>" class="btn btn-danger btn-floating">
                                                <i class="fas fa-file-export"></i>
                                            </a>
                                        </div>
                                        <?php endif; ?>
                                        <div class="table-responsive mt-2">
                                            <?php $session = 2; ?>
                                            <?php if(!isset($result)): ?>
                                            <!-- ('parts.admin.etudiant.table-module-note')-->
                                            <?php else: ?>
                                              <!--  ('parts.admin.etudiant.result-table')-->
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                </div>

                            </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <!-- Tabs content -->


                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="row justify-content-center">Aucune donnée à afficher</div>
        <?php endif; ?>

    </div>

</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/etudiant/semestrenote.blade.php ENDPATH**/ ?>