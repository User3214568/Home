
<div class="row">
    <h2>Années Universitaires Précédentes</h2>
    <hr class="dropdown-divider">
</div>

<div class="row mt-4">
    <?php if(sizeof($formations) == 0): ?>
        <div class="row text-center">
            Vous n'avez pas des années universitaire antérieurs à afficher. Verifier que vous avez
            effectuer les délibration du fin d'année dans la section Etudiants > Délibrations
        </div>
    <?php endif; ?>
    <?php echo $__env->make("parts.admin.old.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\old\index.blade.php ENDPATH**/ ?>