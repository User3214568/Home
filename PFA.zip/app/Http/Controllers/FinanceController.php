<?php

namespace App\Http\Controllers;

use App\Etudiant;
use App\Formation;
use App\Paiement;
use App\Tranche;
use Illuminate\Http\Request;

class FinanceController extends Controller
{



}
