<div class="row card mt-2 semestre" id="sem<?php echo e($semestre->numero); ?>">
            <div class="card-body">
                <h5 class="card-title" id="sem-title">Semestre <?php echo e($semestre->numero); ?></h5>
                <hr class="dropdown-divider">
                <div id="modules-selected" class="card-text wrap">
                    <?php $__currentLoopData = $semestre->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="p-2"><?php echo e($module->name); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <hr class="dropdown-divider">
            </div>
            <div class="mb-2">
                <button type="button" id="edit-sem" class="btn btn-success btn-floating ms-1" data-toggle="modal" data-target="#popup" onclick="editSemestre(this)" name='<?php echo e($semestre->numero); ?>'><i class="fas fa-marker"></i></button>
                <button type="button" id="delete-sem" class="btn btn-danger btn-floating ms-1 " onclick="deleteSemestre(this)" name="<?php echo e($semestre->numero); ?>"><i class="fas fa-trash-alt"></i></button></div></div>
            </div>
</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\formation\selected-semestre.blade.php ENDPATH**/ ?>