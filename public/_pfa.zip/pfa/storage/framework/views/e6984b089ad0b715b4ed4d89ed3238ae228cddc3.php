<div class="row">
    <h2>Professeurs</h2>
    <hr class="dropdiwn-divider">
    <p>Vous pouvez consulter la list des professeurs dans la table ci-dessous ou bien
        ajouter, modifier ou supprimer un professeur.
    </p>
    <div class="note note-info">
        Les professeurs crée par des administrateurs peuvent acceder à leurs espace professeur <?php if(auth()->guard()->check()): ?>
        <br>
        <ul>
            <li><strong>Username : </strong>Prénom.Nom@gest.ma</li>
            <li><strong>Mot de Passe : </strong>Prénom_En_Majuscule@Nom_En_Majuscule</li>
        </ul>
        <?php endif; ?>
    </div>
</div>
<div class="row justify-content-between p-3">
    <div class="col-4 form-outline ">
        <i class="fas fa-search trailing"></i>
        <input type="text" id="etudiants-search" value="" name="name" class="form-control form-icon-trailing"  />
        <label class="form-label"  for="etudiants-search">Rechercher un Professeur</label>
    </div>
    <a href="<?php echo e(route('teacher.create')); ?>" class="btn btn-primary btn-floating">
        <i class="fas fa-plus"></i>
    </a>
</div>

<div class="row table-responsive mt-4">
    <table class="table align-middle table-hover" id="etudiants-table" >
        <thead class="table-dark align-middle">
            <tr>
                <th>Code</th>
                <th>Nom</th>
                <th>Prénom</th>

                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php if(sizeof($teachers) < 1): ?>
            <tr>
                <td colspan="5">Aucun Professeurs à afficher</td>
            </tr>
            <?php else: ?>
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr name="filter">
                    <td><?php echo e($teacher->user->cin); ?></td>
                    <td><?php echo e($teacher->user->first_name); ?></td>
                    <td><?php echo e($teacher->user->last_name); ?></td>

                    <td class="">
                        <a href="<?php echo e(route('teacher.edit',['teacher'=>$teacher->id])); ?>" class="btn btn-success btn-floating">
                            <i class="fas fa-pen-fancy"></i>
                        </a>
                        <form class="d-inline" action="<?php echo e(route('teacher.destroy',['teacher'=>$teacher->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field("delete"); ?>
                        <button class="btn btn-danger btn-floating ">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

        </tbody>
    </table>
</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\teacher\index.blade.php ENDPATH**/ ?>