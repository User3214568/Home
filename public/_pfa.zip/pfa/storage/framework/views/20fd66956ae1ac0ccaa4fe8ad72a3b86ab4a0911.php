<script type="module" src="/javascript/list-payement.js"></script>

<?php $__env->startSection('title-list', 'List des Payements Effectués'); ?>
<?php $__env->startSection('route-import', route('paiement.import',['id'=>0])); ?>
<?php $__env->startSection('route-create', route('paiement.create')); ?>
<?php $__env->startSection('route-export-empty', route('paiement.export', ['id' => 0, 'type' => 'true'])); ?>
<?php $__env->startSection('route-export', route('paiement.export', ['id' => 0, 'type' => 'false'])); ?>
<?php $__env->startSection('table'); ?>
    <?php $paiements = App\Paiement::get()->groupBy('date_payement');
    $size = sizeof($paiements);
    ?>
    <?php if(sizeof($paiements)>0): ?>
        <?php $__currentLoopData = $paiements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $d_paiement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $total = 0; ?>
            <tr>
                <td>

                    <table class="table table-bordered table-sm align-middle text-center text-nowrap ">
                        <tr>
                            <td colspan="5"><?php echo e('Paiement des Professeurs, Le : '); ?><strong><?php echo e($key); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Formation</td>
                            <td>Professeur</td>
                            <td>Montant</td>
                            <td></td>
                        </tr>

                        <?php $__currentLoopData = $d_paiement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paiement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr name="versement">
                                    <td><?php echo e($paiement->formation->name); ?></td>
                                    <td><?php echo e($paiement->teacher->user->first_name." ".$paiement->teacher->user->first_name); ?></td>
                                    <td><?php echo e($paiement->montant); ?></td>
                                    <td class="d-flex justify-content-center  align-items-center">
                                        <form action="<?php echo e(route('paiement.destroy', ['paiement' => $paiement->id])); ?>"
                                            method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button class="btn btn-outline-danger btn-floating">
                                                <i class="fas fa-times  fa-1x"></i>
                                            </button>
                                        </form>
                                        <form action="<?php echo e(route('paiement.edit', ['paiement' => $paiement->id])); ?>"
                                            method="GET">
                                            <button class="btn btn-outline-secondary ms-1 btn-floating">
                                                <i class="fas fa-pen-fancy fa-1x"></i>
                                            </button>
                                        </form>
                                    </td>
                                    <?php $total += $paiement->montant; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr class="table-danger">
                                <td colspan="2">Total Payé</td>
                                <td colspan="3"><?php echo e($total); ?></td>
                            </tr>


                    </table>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div class="p-4 border text-center">
            Aucun paiement à afficher. Verifiez que avez fait des paiements.
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('parts.admin.common.list-payement-tranche', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/finance/consultantspay.blade.php ENDPATH**/ ?>