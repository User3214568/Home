<div class="border  col-md-3 rounded-0 shadow-5 card text-center m-md-4  text-white" style="<?php echo e(App\Utilities\Generate::background_color()); ?>" >
    <div class="card-body d-flex justify-content-between flex-column aling-items-center">
        <div>
            <div class="card-header text-reset"><?php echo e(App\Utilities\Calculation::time_diff($formation->updated_at)); ?></div>
            <h5  class="card-title h4 mt-1 text-wrap"><?php echo e($formation->name); ?></h5>
            <textarea hidden name="sems"><?php echo e($formation); ?></textarea>
        </div>
        <button type="button" class="btn btn-primary rounded-0" name="card-formation">Plus d'informations</button>

    </div>
    <div class="card-footer text-muted">

        <a class="btn btn-success btn-lg btn-floating" href="<?php echo e(route('formation.edit',$formation->id)); ?>">
            <i class="fas fa-pen-nib"></i>
        </a>
        <form class="d-inline" method="post" action="<?php echo e(route('formation.destroy',$formation)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button  class="btn btn-danger btn-lg btn-floating" data-mdb-ripple-color="dark">
                <i class="fas fa-trash-alt"></i>
            </button>
        </form>
    </div>
</div>
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/formation/formation-card.blade.php ENDPATH**/ ?>