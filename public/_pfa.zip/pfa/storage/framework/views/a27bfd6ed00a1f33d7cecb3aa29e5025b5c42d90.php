<!-- Tabs navs -->
<ul class="nav nav-tabs nav-justified mb-3" id="ex1" role="tablist">
    <?php
        $done = false;
    ?>
    <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation => $aus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="nav-item" role="presentation">

      <a
      class="nav-link <?php echo e($done?'':'active'); ?>"
      id="<?php echo e($formation); ?>"
      data-mdb-toggle="tab"
      href="#<?php echo e($formation); ?>-tab"
      role="tab"
      aria-selected="true"
      ><?php echo e($formation); ?></a>
    </li>
    <?php
        $done = true;
    ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </ul>
  <!-- Tabs navs -->
  <?php
      $done = false;
  ?>
  <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation => $aus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="tab-content" id="">
    <div
      class="tab-pane fade <?php echo e($done?'':'show active'); ?>"
      id="<?php echo e($formation); ?>-tab"
      role="tabpanel"
    >
      <?php echo $__env->make('parts.admin.old.au', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>


  </div>
    <?php
        $done = true;
    ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <!-- Tabs content -->
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/old/header.blade.php ENDPATH**/ ?>