<?php
    $login_title = "Récupération de mot de passe";
    $is_login = false;
    $url = '/restore-password';
    $login_footer_btn = "Envoyer l'Email";
?>
<?php echo $__env->make('parts.login.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\pass-forg.blade.php ENDPATH**/ ?>