<script src="/javascript/home.js"></script>
<script>
    var stats = <?php echo json_encode($stats); ?>

    var fin_stats = <?php echo json_encode($fin_stats); ?>

    var total_versments =  <?php echo json_encode($total_versments); ?>

    var total_paiements =  <?php echo json_encode($total_paiements); ?>

</script>
<div class="row">
    <h2>Acceuil</h2>
    <hr class="dropdown-divider">
</div>
<div class=" mt-1 text-left h5 lead">
</div>
<div class="row p-2">
    <div class="p-2 bg-primary border  rounded-top text-light  d-flex ">
        <span class="me-2"><i class="fas fa-bell"></i></span>
        <span>Vos Notifications</span>
    </div>
        <div class="col-md-12 limit">

            <div class="p-2 border rounded-bottom">
                <?php if(sizeof(\Auth::user()->notifications->where('pivot.seen',0)) > 0): ?>
                    <?php $__currentLoopData = \Auth::user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($notif->pivot->seen == 0): ?>
                    <div class="row justify-content-between">
                        <div class="col-10 d-flex justify-content-start align-items-center ">
                            <img class="me-2 rounded-circle" height="30" src="<?php echo e(url(route('avatar',['cin'=> isset($user)?$notif->user->cin:'none']))); ?>" alt="">
                            <span><?php echo e($notif->message); ?></span>
                        </div>
                        <div class="col-2 d-flex justify-content-end">
                            <strong>
                                <?php echo e(\App\Utilities\Calculation::time_diff($notif->created_at,now())); ?>

                            </strong>
                        </div>
                        <?php
                            $notif->pivot->seen = 1 ; $notif->pivot->save();
                        ?>
                    </div>

                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="d-flex justify-content-center align-items-center">
                        <p>Aucune Notification à afficher.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
</div>
<div class="row mt-4 border-bottom border-top justify-content-around text-dark">
    <div class="col-md-3 border-end  bg-transparent">
        <div class="row p-3 d-flex justify-content-between border-bottom">
            <div class="col-6 d-flex flex-column justify-content-center align-items-center">
                <i class="fas fa-user-graduate fa-2x"></i>
                <span >Etudiants</span>
            </div>
            <div class="col-6 d-flex align-items-center justify-content-center">
                <p class="h4"><?php echo e($total_etudiants); ?></p>
            </div>
        </div>
        <div class="row p-3 d-flex justify-content-between border-bottom">
            <div class="col-6 d-flex flex-column justify-content-center align-items-center">
                <i class="fas fa-code-branch fa-2x"></i>
                <span>Formations</span>
            </div>
            <div class="col-6 d-flex align-items-center justify-content-center">
                <p class="h4"><?php echo e($total_formations); ?></p>
            </div>
        </div>
        <div class="row p-3 d-flex justify-content-between border-bottom">
            <div class="col-6 d-flex flex-column justify-content-center align-items-center">
                <i class="fas fa-th fa-2x"></i>
                <span>Modules</span>
            </div>
            <div class="col-6 d-flex align-items-center justify-content-center">
                <p class="h4"><?php echo e($total_modules); ?></p>
            </div>
        </div>
        <div class="row p-3 d-flex justify-content-between ">
            <div class="col-6 d-flex flex-column justify-content-center align-items-center">
                <i class="fas fa-chalkboard-teacher fa-2x"></i>
                <span>Professeurs</span>
            </div>
            <div class="col-6 d-flex align-items-center justify-content-center">
                <p class="h4"><?php echo e($total_profs); ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-9  bg-transparent"  id="chart1">

    </div>

</div>

<div class="row mt-4">
    <hr class="dropdown-divider">
</div>
<div class="row">
    <div class="col-md-6   border-end  align-items-stretch">
        <div>
            <h5>Revenus</h5>
        </div>
        <div>
            <table class="table ">
                <tr><td>-</td><td>-</td><td>-</td></tr>
                <tr>
                    <td>Total Versements</td>
                    <td><?php echo e($total_versments); ?></td>
                    <td>Diirhams</td>
                </tr>
                <tr class="text-success">
                    <td class="h6">Total Revenus</td>
                    <td class="h6"><?php echo e($total_versments); ?></td>
                    <td class="h6">Dirhams</td>
                </tr>
            </table>

        </div>

    </div>
    <div class="col-md-6  ">
        <div>
            <h5>Dépenses Totaux</h5>
        </div>
        <div>
            <table class="table ">
                <tr>
                    <td>Paiement des Professeurs</td>
                    <td><?php echo e($total_paiements); ?></td>
                    <td>Dirhams</td>
                </tr>
                <tr>
                    <td>Dépenses Communes</td>
                    <td><?php echo e($total_deps); ?></td>
                    <td>Dirhams</td>
                </tr>
                <tr class="text-danger">
                    <td class="h6">Total Dépenses</td>
                    <td class="h6"><?php echo e($total_deps + $total_paiements); ?></td>
                    <td class="h6">Dirhams</td>
                </tr>

            </table>

        </div>

    </div>

</div>
<div class="row">
    <div class="col-lg-6 border-end">
        <div class="h6 text-center">Etat Global des versements des Etudiants</div>
        <div id="chart4"></div>
    </div>
    <div class="col-lg-6">
        <div class="h6 text-center">Etat Global du Paiement des Professeurs</div>
        <div id="chart5"></div>
    </div>

</div>
<div class="row">
    <div class="border-end col-md-6">
        <hr class="dropdown-divider">
        <div class="h6 text-center">Etat du Paiement des Etudiants</div>
        <div id="chart2"></div>
    </div>
    <div class=" col-md-6">
        <hr class="dropdown-divider">
        <div class="h6 text-center">Etat du Paiement des Professeurs</div>
        <div id="chart3"></div>
    </div>
</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/dashboard/home.blade.php ENDPATH**/ ?>