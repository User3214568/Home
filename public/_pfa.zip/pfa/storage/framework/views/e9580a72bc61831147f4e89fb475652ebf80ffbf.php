<?php

    $route = route("user.store");
    if(isset($user)){
        $route = route("user.update",$user);
    }
    $fields = [
        ['type'=>'text', 'name'=>'first_name' ,'value' => isset($user)?$user->first_name:'' , 'label'=>'Nom'],
        ['type'=>'text', 'name'=>'last_name' ,'value' => isset($user)?$user->last_name:'', 'label'=>'Prenom'],
        ['type'=>'text', 'name'=>'email' ,'value' => isset($user)?$user->email:'', 'label'=>'L\'email de L\'Utilisateur'],
        ['type'=>'password','name'=>'password' ,'value' =>'','label'=>'Mot de Passe de l\'Utilisateur'],
        ['type'=>'tel', 'name'=>'phone' ,'value' => isset($user)?$user->phone:'', 'label'=>'Numéro de Téléphone'],
    ];
    $target = "Utilisateur";
    if(!isset($user)){
        array_push($fields,['type'=>'text', 'name'=>'cin' ,'value' => isset($user)?$user->cin:'', 'label'=>'Numéro de la crate d\'identité national']);
    }
    ?>
<?php echo $__env->make('parts.admin.common.formulaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/user/user.blade.php ENDPATH**/ ?>