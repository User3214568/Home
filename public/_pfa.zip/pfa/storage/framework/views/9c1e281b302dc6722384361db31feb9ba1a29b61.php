<style>
    .header {
        background-color: orange;
        color: white;
    }

</style>
<table>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>

    <tr>
        <th colspan="3" style="background-color : orange;color: white;font-size : 14px;border :1px solid black">Dépenses</th>
    </tr>
    <tr>
        <th colspan="2" style="font-size : 13px ; border:1px solid black">Motif</th>
        <th colspan="1" style="font-size : 13px ; border:1px solid black">Somme</th>
    </tr>
    <?php $__currentLoopData = $motifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="border:1px solid orange">
            <td colspan="2" style="border:1px solid black"><?php echo e($motif->name); ?></td>
            <td colspan="1" style="border:1px solid black"><?php echo e($motif->somme); ?></td>
            <?php $total += $motif->somme; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <th colspan="1" style="border:1px solid black">Total</th>
        <th  colspan="2" style="border:1px solid black"><?php echo e($total); ?></th>
    </tr>
</table>
<table>
    <tr>
        <th colspan="3" style="background-color : orange;color: white;font-size : 14px;border :1px solid black">Effectifs et Répartition</th>
    </tr>
    <tr>
        <th style="font-size : 13px ; border:1px solid black">Formation</th>
        <th style="font-size : 13px ; border:1px solid black">Effectif</th>
        <th style="font-size : 13px ; border:1px solid black">Part</th>
    </tr>
    <?php $__currentLoopData = $formations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="border:1px solid black"><?php echo e($formation->name); ?></td>
            <td style="border:1px solid black"><?php echo e($formation->getEffectif()); ?></td>
            <td style="border:1px solid black"><?php echo e($total_effectif == 0 ? 0 : ($total * $formation->getEffectif()) / $total_effectif); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>


<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/common/depense/dep-view-excel.blade.php ENDPATH**/ ?>