<p>
<h2><?php echo e(!isset($etudiant) && !isset($teacher) && !isset($user) && !isset($module) && !isset($paiement) && !isset($tranche) && !isset($prof) && !isset($dep) ? 'Ajouter ' . (isset($adj) ? $adj : 'Un Nouveau') . " $target" : "Modifier $target"); ?>

</h2>
</p>
<?php if($errors->any()): ?>
    <div class="note note-danger">
        <p>Attention ! On a pas pu enregistrer l'<?php echo e($target); ?>.</p>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<form class="row container p-3 needs-validation" method="post" action="<?php echo e($route); ?>" novalidate  enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <?php if(isset($etudiant) || isset($teacher) || isset($user) || isset($module) || isset($tranche) || isset($dep) || isset($paiement) || isset($prof)): ?>
        <?php echo method_field('put'); ?>
    <?php endif; ?>
    <?php if($target === "Utilisateur"): ?>
        <script src="/javascript/user.js"></script>
        <div class="d-flex justify-content center align-items-center flex-column">
            <div class="align-self-right">
                <button  id="image_button" type="button" class="btn btn-light btn-floating">
                    <i class="fas fa-edit"></i>
                </button>
                <input type="file" onchange="readImage(this)" name="image" id="image_input" hidden>
            </div>
            <img id="image" class="rounded-circle" src="<?php echo e(url(route('avatar',['cin'=> isset($user)?$user->cin:'none']))); ?>" height="180" alt="user image">
        </div>
    <?php endif; ?>
    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if($field['type'] == 'selection'): ?>

            <select class="mt-4 border rounded-2 p-2 text-reset" name="<?php echo e($field['name']); ?>"
                id="input_<?php echo e($field['name']); ?>" required>
                <option value="<?php echo e($field['value']); ?>" <?php echo e(!isset($etudiant) || !isset($prof) ? 'selected' : ''); ?>

                    disabled>
                    <?php echo e($field['label']); ?></option>
                <?php $__currentLoopData = $field['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($item->id ?: $item->cin); ?>"
                        <?php echo e(isset($etudiant) || (isset($prof) && isset($field['selected']) && $field['selected'] == ($item->id ?: $item->cin)) ? 'selected' : ''); ?>>
                        <?php echo e($item->name ?: ($item->nom ?: $item->user->name())); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        <?php elseif(($field['type'] == 'date')): ?>
            <div class="mt-4 form-outline ">
                <input type="<?php echo e($field['type']); ?>"
                    value="<?php echo e(isset($etudiant) ? $etudiant->born_date : date('Y-m-d')); ?>"
                    id="input_<?php echo e($field['name']); ?>" name="<?php echo e($field['name']); ?>" class="form-control" required />
                <label class="form-label" for="input_<?php echo e($field['name']); ?>"><?php echo e($field['label']); ?></label>
                <div class="invalid-feedback mt-1">Veuillez saisir <?php echo e($field['label']); ?> .</div>
            </div>
        <?php elseif(($field['type'] == 'textarea')): ?>

            <div class="mt-4 form-outline">
                <textarea type="<?php echo e($field['type']); ?>" id="input_<?php echo e($field['name']); ?>"
                    name="<?php echo e($field['name']); ?>" class="form-control" rows="8"
                    required><?php echo e($field['value']); ?></textarea>
                <label class="form-label" for="input_<?php echo e($field['name']); ?>"><?php echo e($field['label']); ?></label>
                <div class="invalid-feedback mt-1">Veuillez saisir <?php echo e($field['label']); ?> .</div>
            </div>

        <?php elseif(($field['type'] == 'checkbox')): ?>
            <div class="form-check mt-4">
                <input class="form-check-input" name="<?php echo e($field['name']); ?>" type="checkbox" value=""
                    id="_<?php echo e($field['name']); ?>"
                    <?php echo e((isset($field['checked']) ? $field['checked'] === 1 : false) ? 'checked' : ''); ?> />
                <label class="form-check-label" for="_<?php echo e($field['name']); ?>">
                    <?php echo e($field['label']); ?>

                </label>
            </div>
        <?php else: ?>

            <div class="mt-4 form-outline">
                <input type="<?php echo e($field['type']); ?>" id="input_<?php echo e($field['name']); ?>"
                    value="<?php echo e($field['value']); ?>" name="<?php echo e($field['name']); ?>" class="form-control" required />
                <label class="form-label" for="input_<?php echo e($field['name']); ?>"><?php echo e($field['label']); ?></label>
                <div class="invalid-feedback mt-1">Veuillez saisir <?php echo e($field['label']); ?> .</div>
            </div>
        <?php endif; ?>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($target == 'Module'): ?>
        <script type="module" src="/javascript/module.js"></script>
        <div class="row mt-4">
            <h5>Gestion des Devoirs de la Session Ordinaire du Module</h5>
        </div>
        <div class="row">
            <p class="text-reset">
                Veuillez ajouter les devoirs du session <span class="text-danger">Ordinaire</span> de votre
                module.
            </p>
        </div>
        <div class="row">
            <hr class="mt-2 dropdown-divider">
        </div>
        <div class="row" id="devoirs">
            <div class="row mt-3 justify-content-center" id="devoirDiv">
                <div class="col-3 form-outline">
                    <input type="text" id="name" class="form-control" />
                    <label class="form-label" for="name">Nom du Devoir</label>
                </div>
                <div class="col-3 ms-2 form-outline">
                    <input type="text" id="ratio" class="form-control" />
                    <label class="form-label" for="ratio">Pourcentage</label>
                </div>

                <div class="col-2">
                    <button type="button" id="check" class="btn btn-info btn-floating" hidden>
                        <i class="fas fa-check"></i>
                    </button>
                    <button type="button" id="addModule" class="btn btn-primary btn-floating">
                        <i class="fas fa-plus"></i>
                    </button>

                </div>
            </div>
        </div>
        <button type="button" id="modal-trigger" class="btn btn-primary" data-toggle="modal" data-target="#popup"
            hidden>
        </button>

        <!-- Devoirs Ratt -->

        <div class="row mt-4">
            <h5>Gestion des Devoirs de la Session Rattrappage du Module</h5>
        </div>
        <div class="row">
            <p class="text-reset">
                Veuillez ajouter les devoirs du session <span class="text-danger">Rattrappage</span> de votre
                module.
            </p>
        </div>
        <div class="row">
            <hr class="mt-2 dropdown-divider">
        </div>
        <div class="row" id="devoirs1">
            <div class="row mt-3 justify-content-center" id="devoirDiv1">
                <div class="col-3 form-outline">
                    <input type="text" id="name" class="form-control" />
                    <label class="form-label" for="name">Nom du Devoir</label>
                </div>
                <div class="col-3 ms-2 form-outline">
                    <input type="text" id="ratio" class="form-control" />
                    <label class="form-label" for="ratio">Pourcentage</label>
                </div>

                <div class="col-2">
                    <button type="button" id="check1" class="btn btn-info btn-floating" hidden>
                        <i class="fas fa-check"></i>
                    </button>
                    <button type="button" id="addModule1" class="btn btn-primary btn-floating">
                        <i class="fas fa-plus"></i>
                    </button>

                </div>
            </div>
        </div>
        <button type="button" id="modal-trigger" class="btn btn-primary" data-toggle="modal" data-target="#popup"
            hidden>
        </button>
        <?php echo $__env->make('parts.admin.common.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <input type="text" id="data" name="devoirs" hidden />
        <?php if(isset($module)): ?>
            <script>
                var devs = <?php echo json_encode($module->devoirs); ?>;
            </script>
        <?php endif; ?>
    <?php endif; ?>
    <div class=" mt-4 mb-4">
        <hr class="dropdown-divider">
    </div>
    <div class=" d-flex justify-content-end">
        <button class="btn btn-success">
            <h6><?php echo e(!isset($etudiant) && !isset($user) && !isset($teacher) && !isset($module) && !isset($tranche) && !isset($paiement) && !isset($prof) && !isset($dep) ? "Crée  $target" : "Modifier  $target"); ?>

            </h6>
        </button>
    </div>
</form>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/common/formulaire.blade.php ENDPATH**/ ?>