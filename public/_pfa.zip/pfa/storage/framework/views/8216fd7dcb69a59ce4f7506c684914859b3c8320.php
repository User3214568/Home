<script src="/javascript/formation-cards.js"></script>

<?php
    $target = 'formation'
?>
<?php echo $__env->make('parts.admin.common.mod-form-index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('parts.admin.common.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/formation/index.blade.php ENDPATH**/ ?>