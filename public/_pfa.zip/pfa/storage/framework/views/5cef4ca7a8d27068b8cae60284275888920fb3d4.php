<div class="row">
    <h2>Liste de Mes Paiements</h2>
    <hr class="dropdown-divider" />
</div>
<table class='table'>
    <tr>
        <th>Formation</th>
        <th>Montant Payé</th>
        <th>Date du Paiement</th>

    </tr>
    <?php if(sizeof($paiements)<1): ?>
        <tr>
            <td colspan="3">Vous n'avez aucun paiement pour le moment.</td>
        </tr>
    <?php else: ?>
        <?php $__currentLoopData = $paiements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paiement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($paiement->formation->name); ?></td>
            <td><?php echo e($paiement->montant); ?></td>
            <td><?php echo e($paiement->date_payement); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</table>
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/enseignant/paiements/paiements.blade.php ENDPATH**/ ?>