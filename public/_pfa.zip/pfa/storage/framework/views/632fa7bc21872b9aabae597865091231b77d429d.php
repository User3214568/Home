<!-- Tabs navs -->
<ul class="nav nav-tabs  nav-justified  mb-3" id="ex1" role="tablist">
    <?php $done  = false; ?>
    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module=>$profs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-item" role="presentation">
            <a class="nav-link <?php echo e($done ? '' : 'active'); ?>" id="module-<?php echo e($module); ?>" data-mdb-toggle="tab"
                href="#tab--mod-<?php echo e(str_replace(' ','',$formation).str_replace(' ','',$module)); ?>" role="tab" aria-selected="true"><?php echo e($module); ?></a>
        </li>
        <?php $done  = true; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</ul>
<!-- Tabs navs -->

<!-- Tabs content -->
<div class="tab-content" id="ex4-content">
    <?php $done  = false; ?>
    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module=>$profs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="tab-pane fade <?php echo e($done?'':'show active'); ?>" id="tab--mod-<?php echo e(str_replace(' ','',$formation).str_replace(' ','',$module)); ?>" role="tabpanel">
            <?php echo $__env->make('parts.enseignant.notes.sessions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <?php $done  = true; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<!-- Tabs content -->
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\enseignant\notes\modules.blade.php ENDPATH**/ ?>