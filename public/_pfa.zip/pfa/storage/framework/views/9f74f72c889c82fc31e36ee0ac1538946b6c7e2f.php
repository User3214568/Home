<div class="row m-1 justify-content-between" >
    <?php echo $__env->make('parts.admin.dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="col-md-9 " id="admin-content">

        <?php if(!isset($content)): ?>
            <?php echo $__env->make('parts.enseignant.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <?php echo $__env->make($content, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </div>
</div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/enseignant/dash/ens-content.blade.php ENDPATH**/ ?>