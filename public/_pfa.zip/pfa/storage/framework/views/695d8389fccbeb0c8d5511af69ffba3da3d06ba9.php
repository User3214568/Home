<script type="module" src="/javascript/list-prof.js"></script>

<?php $__env->startSection('title-list', 'Liste des Professeurs'); ?>
<?php $__env->startSection('route-import', route('professeur.import', ['id' => 0])); ?>
<?php $__env->startSection('route-create', route('professeur.create')); ?>
<?php $__env->startSection('route-export', route('professeur.export', ['id' => 0, 'type' => 'false'])); ?>
<?php $__env->startSection('route-export-empty', route('professeur.export', ['id' => 0, 'type' => 'true'])); ?>
<?php $__env->startSection('table'); ?>

    <tr>
        <th>Formation</th>
        <th>Module</th>
        <th>Professeur</th>
        <th>Somme</th>
        <th></th>
    </tr>
    <?php if(sizeof($allprofs) > 0 ): ?>
        <?php $__currentLoopData = $allprofs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation_name => $profs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = $profs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prof): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr name="versement">

                    <td><?php echo e($formation_name); ?></td>
                    <td><?php echo e($prof->module->name); ?></td>
                    <td><?php echo e($prof->teacher->user->first_name." ".$prof->teacher->user->last_name); ?></td>
                    <td><?php echo e($prof->somme); ?></td>

                    <td class="d-flex justify-content-center  align-items-center">
                        <form action="<?php echo e(route('professeur.destroy', ['professeur' => $prof->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('delete'); ?>
                            <button class="btn btn-outline-danger btn-floating">
                                <i class="fas fa-times  fa-1x"></i>
                            </button>
                        </form>
                        <form action="<?php echo e(route('professeur.edit', ['professeur' => $prof->id])); ?>" method="GET">
                            <button class="btn btn-outline-secondary ms-1 btn-floating">
                                <i class="fas fa-pen-fancy fa-1x"></i>
                            </button>
                        </form>
                    </td>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td colspan="5">Aucune donnée à afficher.</td>
        </tr>
        <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('parts.admin.common.list-payement-tranche', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/Professeur/list-prof.blade.php ENDPATH**/ ?>