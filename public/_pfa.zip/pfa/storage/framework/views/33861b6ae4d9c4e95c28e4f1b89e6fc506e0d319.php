<div class="col-md-3 " id="mysidebar" style="font-size: 13px">
    <div class="row position-fixed d-flex justify-content-center align-items-center"  id="sidebartoggler">
        <button class="d-none d-md-block btn btn-primary btn-floating ">
            <i name="icon-sidebar" class="fas fa-bars"></i>
        </button>
        <button id="sidebarHideToggler" class="d-block d-md-none ms-1 btn btn-primary btn-floating ">
            <i class="fas fa-angle-up"></i>
        </button>
    </div>
    <div class="row" id="side">

        <div class="mt-5 d-flex align-items-center flex-column">
            <img name="side-item-label" src="<?php echo e(url(route('avatar', ['cin' => Auth::user()->cin]))); ?>" class="rounded-circle p-3" height="150"
                alt="" />
            <h5 class=""><span name=" side-item-label"><strong><span
                        name="side-item-label"><?php echo e(Auth::user()->first_name); ?> <?php echo e(' '); ?>

                        <?php echo e(Auth::user()->last_name); ?></span></strong></span></h5>
            <p class="text-muted"><span name="side-item-label"><?php echo e(Auth::user()->email); ?></span></p>
        </div>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(isset($item['divider'])): ?>
                <div class="border-top pt-2 row">
                    <span name="side-item-label">
                        <h6><?php echo e($item['title']); ?></h6>
                    </span>
                </div>
            <?php else: ?>
                <?php if($item['expanded']): ?>
                    <a href="#" class="row text-reset p-2 sidebar-item justify-content-between " data-mdb-toggle="collapse"
                        data-mdb-target="<?php echo e('#' . $item['title']); ?>" aria-expanded="false">
                        <div class="col">
                            <i name="icon-sidebar" class="<?php echo e($item['icon']); ?>"></i>
                            <span class="ms-2" name="side-item-label"><?php echo e($item['title']); ?></span>
                        </div>
                        <i class="col-1 d-flex justify-content-between fas fa-angle-right align-self-center" ></i>
                    </a>
                    <div class="collapse ms-3" id="<?php echo e($item['title']); ?>">
                        <?php $__currentLoopData = $item['sub_items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="sub-item p-1">
                                <a href="<?php echo e($sub_item['link']); ?>" class="row text-reset">
                                    <i name="icon-sidebar" class="col-1 <?php echo e($sub_item['icon']); ?>"></i>
                                    <span class="col-10 "
                                        name="side-item-label"><?php echo e($sub_item['title']); ?></span>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php else: ?>
                    <a href="<?php echo e(isset($item['link']) ? $item['link'] : ''); ?>"
                        class="row text-reset p-2 sidebar-item">
                        <div class="col ">
                            <i name="icon-sidebar" class="<?php echo e($item['icon']); ?>"></i>
                            <span class="ms-2" name="side-item-label"><?php echo e($item['title']); ?></span>
                        </div>
                    </a>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div>
            <hr class="dropdown-divider">
        </div>
        <a href="<?php echo e(route('user.edit',Auth::user()->cin)); ?>" class="row text-reset p-2 sidebar-item">
            <div class="col -6">
                <i  name="icon-sidebar" class="fas fa-user-edit"></i>
                <span class="ms-2" name="side-item-label">Editer Mon Profile</span>
            </div>

        </a>
        <a href="<?php echo e(route('logout')); ?>" class="row text-reset p-2 sidebar-item active">
            <div class="col -6">
                <i name="icon-sidebar" class="fas fa-sign-out-alt"></i>
                <span class="ms-2" name="side-item-label">Se Déconnecter</span>
            </div>

        </a>
    </div>
</div>
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/dashboard/sidebar.blade.php ENDPATH**/ ?>