
<?php
$route = route('tranche.store');
if(isset($tranche)){
    $route = route('tranche.update',['tranche'=>$tranche->id]);
}
$target = 'Tranche';

$fields = [
    ['type'=>'text','name'=>'etudiant_cin','value'=>$tranche->etudiant->user->cin,'label'=>'Le Numéro du CIN de L\'Etudiant'],
    ['type'=>'text','name'=>'vers','value'=>$tranche->vers,'label'=>'Le Montant Versé'],
    ['type'=>'text','name'=>'ref','value'=>$tranche->ref,'label'=>'Référence du Versement'],
    ['type'=>'date','name'=>'date_vers','value'=> $tranche->date_vers,'label'=>'Date du Versement'],
    ['type'=>'checkbox','name'=>'proved','checked'=>$tranche->proved,'label'=>'Versement Vérifier'],
];

?>
<?php echo $__env->make('parts.admin.common.formulaire', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/finance/edit-tranche.blade.php ENDPATH**/ ?>