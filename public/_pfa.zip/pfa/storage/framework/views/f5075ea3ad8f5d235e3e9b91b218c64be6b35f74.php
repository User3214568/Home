<?php if(!$pass): ?>
    <form method="POST" action="<?php echo e(route('etudiant.finaliser')); ?>" class="row justify-content-end">
        <?php echo csrf_field(); ?>
        <input type="text" value="" id="results-obj" name="results" hidden>
        <button type="submit" id="submit-result" hidden></button>
        <button type="button" id="syn-submit" class="btn btn-primary ">Confirmer les Résultats du Fin d'Année</button>
    </form>
<?php else: ?>
    <div class="row border p-5">
        Vous avez déja fait la délibration des résultats des étudiants de cet formation.
    </div>
<?php endif; ?>
<div class="row  p-1 mt-1">
    <!-- Tabs navs -->
    <ul class="nav  nav-tabs nav-justified mb-3 " id="ex1" role="tablist">
        <?php $done = false; ?>
        <?php $__currentLoopData = $formation->promotions->sortBy('numero'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item" role="presentation">
                <a
                class="nav-link <?php echo e($done?'':'active'); ?>"
                id="tab-<?php echo e($promo->numero); ?>"
                data-mdb-toggle="tab"
                href="#tabs-<?php echo e($promo->numero); ?>"
                role="tab"
                aria-controls="tabs-<?php echo e($promo->numero); ?>"
                aria-selected="true"
                ><?php echo e($promo->nom); ?></a>
            </li>
            <?php $done = true; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <!-- Tabs navs -->

    <div class="tab-content" id="content">
        <?php $done = false; ?>
            <?php $__currentLoopData = $formation->promotions->sortBy('numero'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="tab-pane fade <?php echo e($done?'':'show active'); ?>"
                    id="tabs-<?php echo e($promotion->numero); ?>"
                    role="tabpanel"
                    aria-labelledby="tab-<?php echo e($promotion->numero); ?>"
                >
                    <?php echo $__env->make('parts.admin.etudiant.delib-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <?php $done = true; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <?php if(sizeof($formation->promotions) < 1 ): ?>
    <p class="text-center">La formation <?php echo e($formation->name); ?> n' a aucune promotion à afficher</>
    <?php endif; ?>
</div>
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/etudiant/delib-result.blade.php ENDPATH**/ ?>