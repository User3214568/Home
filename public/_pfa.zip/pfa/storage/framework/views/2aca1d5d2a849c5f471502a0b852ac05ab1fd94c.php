<div class="table-responsive">
    <table class="table align-middle">
        <thead>
            <tr>

                <th>CIN</th>
                <th>Nom</th>
                <th>Prénom</th>
                <th>Résultat</th>
                <th>NV</th>
                <th>AJ</th>
                <th>Décision Final</th>
            </tr>
        </thead>
        <tbody>
            <?php if(sizeof($promotion->etudiants)>0): ?>
                <?php $__currentLoopData = $promotion->etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                        <td><?php echo e($etudiant->user->cin); ?></td>
                        <td><?php echo e($etudiant->user->first_name); ?></td>
                        <td><?php echo e($etudiant->user->last_name); ?></td>
                        <?php
                            $result = \App\Utilities\Validation::result($etudiant->cin)
                        ?>
                        <td><?php echo e($result['note']); ?></td>
                        <th class="text-warning"><?php echo e($result['nv']); ?></td>
                        <th class="text-danger"><?php echo e($result['aj']); ?></td>
                        <th>
                            <select class="p-2" name="select-decision" id="<?php echo e($promotion->id); ?>" e="<?php echo e($etudiant->cin); ?>">
                                <option value="0" <?php echo e($result['final']==1?'selected':''); ?>>Validé(e)</option>
                                <option value="1" <?php echo e($result['final']==0?'selected':''); ?>>Ajourné(e)</option>
                            </select>
                        </th>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr><td>Aucun étudiant n'appartient à cet Promotion.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/etudiant/delib-table.blade.php ENDPATH**/ ?>