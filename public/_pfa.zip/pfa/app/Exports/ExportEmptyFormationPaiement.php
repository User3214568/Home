<?php

namespace App\Exports;

use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromView;
use Maatwebsite\Excel\Concerns\WithColumnFormatting;
use Maatwebsite\Excel\Concerns\WithColumnWidths;
use Maatwebsite\Excel\Concerns\WithFormatData;
use Maatwebsite\Excel\Concerns\WithTitle;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Reader\Xml\Style\NumberFormat;
use PhpOffice\PhpSpreadsheet\Shared\Date;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat as StyleNumberFormat;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class ExportEmptyFormationPaiement extends TemplateExport implements FromView,WithTitle,WithColumnWidths
{
    public function __construct($formation)
    {
        $this->formation = $formation;
        parent::__construct($formation->name,'Paiement des Professeurs',3);
    }
    /**
    * @return \Illuminate\Support\Collection
    */
    public function additionalStyles(Worksheet $sheet, $styles)
    {
        $styles["11"] = [];
        for ($i=0; $i < 3 ; $i++) {
            $styles[chr(65+$i)."11"] = [];
        }
        return $styles;
    }
    public function view(): View
    {
        return view('parts.admin.finance.empty-paiement',['formation'=>$this->formation]);
    }
    public function columnWidths(): array
    {
        return [
            'A'=>30,'B'=>50,'C'=>15
        ];
    }
    public function title(): string
    {
        return $this->formation->name;
    }
}
