
php artisan migrate:refresh --path=/database/migrations/2014_10_12_000000_create_users_table.php
php artisan migrate:refresh --path=/database/migrations/2014_10_12_100000_create_password_resets_table.php
php artisan migrate:refresh --path=/database/migrations/2019_08_19_000000_create_failed_jobs_table.php
php artisan migrate:refresh --path=/database/migrations/2021_08_18_131031_create_formation_table.php
php artisan migrate:refresh --path=/database/migrations/2021_08_18_131707_create_module_table.php
php artisan migrate:refresh --path=/database/migrations/2021_08_21_175003_create_semestres_table.php
php artisan migrate:refresh --path=/database/migrations/2021_08_21_175122_create_semestre_module_table.php
php artisan migrate:refresh --path=/database/migrations/2021_08_22_215136_create_promotions_table.php
php artisan migrate:refresh --path=/database/migrations/2021_08_26_214621_create_promotion_semestre_table.php
php artisan migrate:refresh --path=/database/migrations/2021_08_18_114053_create_etudiant_table.php
php artisan migrate:refresh --path=/database/migrations/2021_08_26_230829_create_devoirs_table.php
php artisan migrate:refresh --path=/database/migrations/2021_08_29_165417_update_devoirs_table.php
php artisan migrate:refresh --path=/database/migrations/2021_08_27_151315_create_evaluations_table.php
php artisan migrate:refresh --path=/database/migrations/2021_08_29_182703_update_formations_table.php
php artisan migrate:refresh --path=/database/migrations/2021_09_01_194144_create_tranches_table.php
php artisan migrate:refresh --path=/database/migrations/2021_09_06_133414_create_teachers_table.php
php artisan migrate:refresh --path=/database/migrations/2021_09_04_081834_create_professeurs_table.php
php artisan migrate:refresh --path=/database/migrations/2021_09_02_114356_create_paiements_table.php
php artisan migrate:refresh --path=/database/migrations/2021_09_05_135918_update_etudiants_table.php
php artisan migrate:refresh --path=/database/migrations/2021_09_07_092322_create_depenses_table.php
php artisan migrate:refresh --path=/database/migrations/2021_09_13_151303_create_notifications_table.php
php artisan migrate:refresh --path=/database/migrations/2021_09_21_142318_create_histories_table.php
php artisan migrate:refresh --path=/database/migrations/2021_09_21_143019_create_hisresults_table.php
php artisan migrate:refresh --path=/database/migrations/2021_09_22_235638_create_tokens_table.php
php artisan migrate:refresh --path=/database/migrations/2021_10_10_163306_add_formation_price.php
php artisan migrate:refresh --path=/database/migrations/2021_10_14_202542_create_graduateds_table.php
php artisan migrate:refresh --path=/database/migrations/2021_10_29_190809_update_professeur_table.php
#User::create(['first_name'=>'Mahfoud','last_name'=>'Hamza','cin'=>'A1000','email'=>'hamza@gmail.com','password'=>bcrypt('hashed'),'type'=>0])


