import ListGesionnaire from "./versement.js";
new ListGesionnaire('/admin/etudiant/export/','/admin/etudiant/import/',1);
