import ListGesionnaire from "./versement.js";
new ListGesionnaire('/admin/finance/export/','/admin/finance/import/formation');
