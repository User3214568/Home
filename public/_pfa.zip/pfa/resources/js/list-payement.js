import ListGesionnaire from "./versement.js";
new ListGesionnaire('/admin/finance/export/paiement/','/admin/finance/import/paiement/',1);
