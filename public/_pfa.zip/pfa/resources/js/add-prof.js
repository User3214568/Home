import Fetch from "./fetch.js";
new Fetch('/admin/formation/modules/');
