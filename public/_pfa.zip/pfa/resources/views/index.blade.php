@extends('parts.layout.page')

@section('title')
    Gestionnaire de Formation | Gestion Pédagogique et Financiére
@stop

@section('content')
    @include('parts.layout.navbar')
    @include('parts.index.index-content')
    @include('parts.layout.footer')
@stop

