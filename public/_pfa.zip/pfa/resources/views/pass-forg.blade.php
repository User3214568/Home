<?php
    $login_title = "Récupération de mot de passe";
    $is_login = false;
    $url = '/restore-password';
    $login_footer_btn = "Envoyer l'Email";
?>
@include('parts.login.login')
