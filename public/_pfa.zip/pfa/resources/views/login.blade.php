<?php
    $login_title = "Accéder à Votre Compte";
    $is_login = true;
    $login_footer_btn = "Connexion";
?>
</div>
@include('parts.login.login')
