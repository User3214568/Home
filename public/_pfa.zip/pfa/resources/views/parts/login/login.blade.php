@extends('parts.layout.page')

@section('title')
    Se Connecter au Gestionnaire des Formations
@stop



@section('content')
    @include('parts.layout.navbar')
    @include('parts.login.login-content')
    @include('parts.layout.footer')
@stop

