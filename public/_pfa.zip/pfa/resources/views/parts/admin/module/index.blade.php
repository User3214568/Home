<?php
    $target = 'module'
?>
@include('parts.admin.common.mod-form-index')
