<div class="row  mt-5 justify-content-center">
    <div class="border p-4 col-6 d-flex flex-column justify-content-center align-items-center">
        <i class="fas fa-times-circle fa-8x text-danger"></i>
        <h2 class="text-danger mt-4">Une Erreur à été survenu</h2>
        <div class="mt-3">
           {{$error}}
        </div>
    </div>
</div>
<div class="row justify-content-end">
    <a href="/" class="btn btn-link">Acceuil</a>
</div>

