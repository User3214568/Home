<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Depenses extends Model
{
    protected $fillable = ['name','somme'];
}
