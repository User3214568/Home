<script src="/javascript/formation-cards.js"></script>

<?php
    $target = 'formation'
?>
@include('parts.admin.common.mod-form-index')
@include('parts.admin.common.modal')
