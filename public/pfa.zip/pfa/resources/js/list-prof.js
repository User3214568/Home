import ListGesionnaire from "./versement.js";
new ListGesionnaire('/admin/professeur/export/','/admin/professeur/import/',1);

