<script src="/javascript/teacher.js"></script>
<div class="row p-2">
    <h2>Historique des Affectations des Professeurs</h2>
    <hr class="dropdiwn-divider">
</div>
<div class="row justify-content-between p-3">
    <div class="col-4 form-outline ">
        <i class="fas fa-search trailing"></i>
        <input type="text" id="etudiants-search" value="" name="name" class="form-control form-icon-trailing" />
        <label class="form-label" for="etudiants-search">Rechercher un Professeur</label>
    </div>
</div>

<div class="row table-responsive mt-4 p-2">
    <table class="table align-middle table-hover" id="etudiants-table">
        <tr>
            <th>Formation</th>
            <th>Module</th>
            <th>Professeur</th>
            <th>Date Affectation</th>
            <th>Somme</th>
            <th></th>
        </tr>
        <?php if(sizeof($allprofs) > 0 ): ?>
            <?php $__currentLoopData = $allprofs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $formation_name => $profs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $passed = false;?>
                <?php $__currentLoopData = $profs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prof): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr name="filter">
                        <?php if(!$passed): ?>
                        <?php $passed = true; ?>
                        <td  rowspan="<?php echo e(sizeof($profs)); ?>"><?php echo e($formation_name); ?></td>
                        <?php endif; ?>
                        <td hidden><?php echo e($formation_name); ?></td>
                        <td><?php echo e($prof->module->name); ?></td>
                        <td><?php echo e($prof->teacher->user->name()); ?></td>
                        <td><?php echo e($prof->created_at); ?></td>
                        <td><?php echo e($prof->somme); ?></td>
                        <td class="d-flex justify-content-center  align-items-center">
                            <form action="<?php echo e(route('professeur.destroy', ['professeur' => $prof->id])); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-outline-danger btn-floating">
                                    <i class="fas fa-times  fa-1x"></i>
                                </button>
                            </form>
                        </td>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
            <tr>
                <td colspan="5">Aucune donnée à afficher.</td>
            </tr>
            <?php endif; ?>
    </table>
</div>
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/Professeur/history.blade.php ENDPATH**/ ?>