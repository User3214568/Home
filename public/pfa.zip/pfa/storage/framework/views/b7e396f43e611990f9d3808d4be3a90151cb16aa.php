<!-- Footer -->
<footer class="text-center text-lg-start bg-transparent text-muted mt-5">
    <!-- Section: Social media -->

    <div class="text-center text-primary p-4">
      © 2021 Copyright:
      <a class="text-reset fw-bold">stagepfa.com</a>
    </div>
    <!-- Copyright -->
  </footer>
  <!-- Footer -->
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/layout/footer.blade.php ENDPATH**/ ?>