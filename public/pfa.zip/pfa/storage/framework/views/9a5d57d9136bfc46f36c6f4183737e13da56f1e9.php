<div class="row  d-flex justify-content-center align-items-center p-2" id="modules">
    <div id="selected" class="w-100">
        <?php if(!(sizeof($semestres) == 0)): ?>
        <span class="text-reset" id="semestre-empty" <?php echo e(isset($formation)?'hidden':''); ?>>Aucune semestre n'est crée pour le moment</span>
        <?php endif; ?>
        <?php if(isset($formation)): ?>
        <?php $__currentLoopData = $formation->semestres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $semestre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="row card mt-2 semestre" id="sem<?php echo e($semestre->numero); ?>">
                <div class="card-body">
                    <h5 class="card-title" id="sem-title">Semestre <?php echo e($semestre->numero); ?></h5>
                    <hr class="dropdown-divider">
                    <div id="modules-selected" class="card-text wrap">
                        <?php $__currentLoopData = $semestre->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <span class="p-2"><?php echo e($module->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <hr class="dropdown-divider">
                </div>
                <div class="mb-2">
                    <button type="button" id="edit-sem" class="btn btn-success btn-floating ms-1" data-toggle="modal" data-target="#popup" onclick="editSemestre(this)" name='<?php echo e($semestre->numero); ?>'><i class="fas fa-marker"></i></button>
                    <button type="button" id="delete-sem" class="btn btn-danger btn-floating ms-1 " onclick="deleteSemestre(this)" name="<?php echo e($semestre->numero); ?>"><i class="fas fa-trash-alt"></i></button></div></div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
</div>
    <div class="row d-flex justify-content-end">
        <button id="add-formation-btn" type="button" class="btn btn-primary btn-floating ms-1 mt-2 align-self-right " data-toggle="modal" data-target="#popup">
            <i class="fas fa-plus"></i>
        </button>

    <?php echo $__env->make('parts.admin.common.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\formation\semestre.blade.php ENDPATH**/ ?>