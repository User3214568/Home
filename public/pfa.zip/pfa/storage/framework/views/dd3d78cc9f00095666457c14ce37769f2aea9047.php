<?php
    $login_title = "Accéder à Votre Compte";
    $is_login = true;
    $login_footer_btn = "Connexion";
?>
</div>
<?php echo $__env->make('parts.login.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/fedorauser/pfa/resources/views/login.blade.php ENDPATH**/ ?>