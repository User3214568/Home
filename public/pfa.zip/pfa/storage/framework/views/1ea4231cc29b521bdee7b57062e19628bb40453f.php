    <script src="/javascript/formation.js"></script>
    <p><h2><?php echo e(isset($formation)?'Editer La Formation '.$formation->name:'Ajouter Une Nouvelle Formation'); ?></h2></p>
    <?php if($errors->any()): ?>
        <div class="note note-danger">
            <p>Attention ! On a pas pu enregistrer la Formation.</p>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form class="row container pl-5 pr-5 needs-validation" method="post" action="<?php echo e(isset($formation)?route('formation.update',$formation):route('formation.store')); ?>" novalidate>
        <?php echo csrf_field(); ?>
        <?php if(isset($formation)): ?>
            <?php echo method_field('put'); ?>
        <?php endif; ?>

        <p><h5>Information de la Formation</h5><hr class="dropdown-divider"></p>
        <div class="form-outline">
            <input type="text" id="input_name" name="name" class="form-control" value="<?php echo e(isset($formation)?$formation->name:''); ?>" required />
            <label class="form-label"  for="input_name">Nom de la Formation</label>
            <div class="invalid-feedback mt-1">Veuillez saisir le nom de la formation.</div>
        </div>
        <div class="form-outline mt-4">
            <textarea class="form-control" id="input_desc" name="description" rows="8" required><?php echo e(isset($formation)?$formation->description:''); ?></textarea>
            <label class="form-label" for="input_desc">Description de la Formation</label>
            <div class="invalid-feedback mt-1">Veuillez saisir la description de la formation.</div>
        </div>
        <div class="form-outline mt-4">
            <input type="number" id="input_prix" name="prix" class="form-control" value="<?php echo e(isset($formation)?$formation->prix:''); ?>" required />
            <label class="form-label"  for="input_prix">Prix de la Formation</label>
            <div class="invalid-feedback mt-1">Veuillez saisir le prix de la formation.</div>
        </div>
        <div class="row mt-5"><h5>Régles de Validates des Modules et Semestres</h5></div>
        <div class="row"><hr class="dropdown-divider"></div>
        <p>Dans cette Zone vous remplissez les critères de validation des modules et des Semestre</p>
        <div class="row justify-content-center">
            <div class="col-sm-5 form-outline ms-2 mt-1">
                <input class="form-control" id="note_validation" value="<?php echo e(isset($formation)?$formation->critere->note_validation:''); ?>" name="note_validation" required/>
                <label class="form-label" for="note_validation">Note de Validation</label>
                <div class="invalid-feedback mt-1">Veuillez saisir la note de validation.</div>
            </div>
            <div class="col-sm-5 form-outline ms-2 mt-1">
                <input class="form-control" id="note_validation" name="note_aj" value="<?php echo e(isset($formation)?$formation->critere->note_aj:''); ?>" required/>
                <label class="form-label" for="note_aj">Note d'Ajournement</label>
                <div class="invalid-feedback mt-1">Veuillez saisir la note d'Ajournement.</div>
            </div>
            <div class="col-sm-5 form-outline ms-2 mt-4">
                <input class="form-control" id="aj" name="number_aj" value="<?php echo e(isset($formation)?$formation->critere->number_aj:''); ?>" required/>
                <label class="form-label" for="aj">Nombre des AJ autorisé</label>
                <div class="invalid-feedback mt-1">Veuillez saisir le nombre des modules ajournées autorisé.</div>
            </div>
            <div class="col-sm-5 form-outline ms-2 mt-4">
                <input class="form-control" id="nv" name="number_nv" value="<?php echo e(isset($formation)?$formation->critere->number_nv:''); ?>"  required/>
                <label class="form-label" for="nv">Nombre des NV autorisé</label>
                <div class="invalid-feedback mt-1">Veuillez saisir le nombre des modules non validées autorisé.</div>
            </div>
        </div>
        <div class=" d-flex justify-content-start flex-column   mt-4">
            <div class="w-100">
                <p class="text-reset"><h5>Répartion des Semestres</h5></p>
                <p><hr class="dropdown-divider"></p>
            </div>
            <div class="w-100" id="semestres">
                <?php echo $__env->make('parts.admin.formation.add-sem', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <div class="mt-4 d-flex justify-content-end">
            <button class="btn btn-success"><h6><?php echo e(isset($formation)?'Modifier La Formation':'Crée La Formation'); ?></h6></button>
        </div>
        <input type="text" value="" name="semestres" hidden id="semestres-data" />
    </form>

    <?php if(isset($formation)): ?>
    <script>
        var semestres = <?php echo json_encode($formation->semestres->ids); ?>


    </script>
    <?php endif; ?>
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/formation/formation.blade.php ENDPATH**/ ?>