

  <!-- Modal -->
  <div class="modal fade" id="popup"  role="dialog" aria-hidden="true">
    <div class="modal-dialog" role="document" id="modal-dialog">
      <div class="modal-content" id="modalContent">
        <div class="modal-header d-flex flex-column text-white border-white" id="modal-header" >
          <h5 class="modal-title" id="modal-title-id"></h5>
        </div>
        <div class="modal-body" id="modal-id">

        </div>
        <div class="modal-footer" id="modal-footer">
          <button type="button" id="close-popup" class="btn btn-secondary" data-dismiss="modal" >Fermer</button>
        </div>
      </div>
    </div>
  </div>
  <button type="button" id="modal-trigger" data-toggle="modal"   data-target="#popup" hidden></button>
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/common/modal.blade.php ENDPATH**/ ?>