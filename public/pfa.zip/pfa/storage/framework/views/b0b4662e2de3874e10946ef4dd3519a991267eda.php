<!-- Tabs navs -->
<ul class="nav nav-tabs mb-3" id="ex1" role="tablist">
    <li class="nav-item" role="presentation">
      <a
        class="nav-link active"
        id="sord"
        data-mdb-toggle="tab"
        href="#tab--mod-<?php echo e(str_replace(' ','',$formation).str_replace(' ','',$module)); ?>-sord"
        role="tab"
        aria-selected="true"
        >Session Ordinaire</a
      >
    </li>
    <li class="nav-item" role="presentation">
        <a
        class="nav-link "
        id="srat"
        data-mdb-toggle="tab"
        href="#tab--mod-<?php echo e(str_replace(' ','',$formation).str_replace(' ','',$module)); ?>-srat"
        role="tab"
        aria-selected="true"
        >Session Rattrappage</a
      >
    </li>

  </ul>
  <!-- Tabs navs -->

  <!-- Tabs content -->
  <div class="tab-content" id="ex1-content">
    <div
      class="tab-pane fade show active"
      id="tab--mod-<?php echo e(str_replace(' ','',$formation).str_replace(' ','',$module)); ?>-sord"
      role="tabpanel"
    >
        <?php
            $session = 1;
        ?>
      <?php echo $__env->make('parts.enseignant.notes.notes-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div
      class="tab-pane fade"
      id="tab--mod-<?php echo e(str_replace(' ','',$formation).str_replace(' ','',$module)); ?>-srat"
      role="tabpanel"
    >
        <?php
            $session = 2;
        ?>
        <?php echo $__env->make('parts.enseignant.notes.notes-table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
  </div>
  <!-- Tabs content -->
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\enseignant\notes\sessions.blade.php ENDPATH**/ ?>