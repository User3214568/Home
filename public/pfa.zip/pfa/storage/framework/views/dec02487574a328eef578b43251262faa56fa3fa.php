<tr>
    <th scope="row"><?php echo e($etudiant->user->name()); ?></th>
    <?php $__currentLoopData = $sem->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!isset($auth_modules) || (isset($auth_modules) && in_array($module->id, $auth_modules))): ?>

            <?php if(sizeof($module->devoirs) > 0): ?>
                <?php $__currentLoopData = $module->devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devoir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($devoir->session == $session): ?>
                        <?php $evaluation = $etudiant->evaluations->where('devoir_id', $devoir->id)->first(); ?>
                        <?php if($evaluation): ?>

                            <td class="border" name="note" id="<?php echo e($evaluation->id); ?>"
                                contenteditable="true">
                                <?php echo e($evaluation->note ?: 0); ?>

                            </td>
                            <?php
                                echo "count  : $mycount";
                                $mycount++;
                            ?>
                        <?php else: ?>
                            <td class="border" contenteditable="false">
                                Non Rattrappant
                            </td>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <td>Aucune Note</td>
            <?php endif; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tr>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\admin\etudiant\all-modules-etudiant.blade.php ENDPATH**/ ?>