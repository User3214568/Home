<div class="row">
    <h2>Mes Résultats</h2>
    <hr class="dropdown-divider">
</div>

<table class="table table-border mt-3">
    <tr>
        <th>Module</th>
        <th>Note</th>
        <th>Résultat</th>
    </tr>
    <?php $__currentLoopData = $modules_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <th><?php echo e($item['name']); ?></th>
        <td><?php echo e($item['note']); ?></td>
        <td><?php echo e($item['result']); ?></td>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views\parts\etudiant\results.blade.php ENDPATH**/ ?>