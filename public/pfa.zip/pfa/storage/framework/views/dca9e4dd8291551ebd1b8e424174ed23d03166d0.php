<script src="/javascript/module-note.js"></script>
<script src="/javascript/evaluation.js"></script>
<h5 class="mt-5">Notes Des Etudiants</h5>
<div class="row mt-1"><hr class="dropdown-divider"></div>
<?php if(isset($result)): ?>

<div class="row justify-content-around">
    <a  href="<?php echo e(route('etudiant.notes.export',['id'=>$formation->id])); ?>" class="col-6 btn btn-success">
        Exporter Les Résultats Finaux du Formation <?php echo e($formation->name); ?>

    </a>
</div>
<div class="row mt-1"><hr class="dropdown-divider"></div>
<?php endif; ?>
<div class="row  p-1 mt-1">
    <!-- Tabs navs -->
    <ul class="nav  nav-tabs nav-justified mb-3 " id="ex1" role="tablist">
        <?php $__currentLoopData = $formation->promotions->sortBy('numero'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$promo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li name="triggers-promo" class="nav-item" role="presentation">
                <a
                class="nav-link <?php echo e($promo->numero > 1 ? ' ' : 'active'); ?>"
                id="tab-<?php echo e($promo->numero); ?>"
                data-mdb-toggle="tab"
                href="#tabs-<?php echo e($promo->numero); ?>"
                role="tab"
                aria-controls="tabs-<?php echo e($promo->numero); ?>"
                aria-selected="true"
                ><?php echo e($promo->nom); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <!-- Tabs navs -->

    <div class="tab-content" id="content">
            <?php $__currentLoopData = $formation->promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="tab-pane fade <?php echo e($promotion->numero > 1 ? ' ':'show active'); ?>"
                    id="tabs-<?php echo e($promotion->numero); ?>"
                    role="tabpanel"
                    aria-labelledby="tab-<?php echo e($promotion->numero); ?>"
                >
                    <?php echo $__env->make('parts.admin.etudiant.semestrenote', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <?php echo $__env->make('parts.admin.common.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/etudiant/tabnotes.blade.php ENDPATH**/ ?>