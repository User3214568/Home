
<table>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <thead>
        <tr>
            <td style="font-size: 14px;font-weight: bold;background-color: orange; border : 1px solid black" colspan="2">Date</td>
            <td style="font-size: 14px;font-weight: bold;background-color: orange; border : 1px solid black" colspan="1"></td>
        </tr>
        <tr>
            <td  colspan="2" style="font-size: 14px;font-weight: bold;background-color: skyblue ; border : 1px solid black" >Professeur</td>
            <td style="font-size: 14px;font-weight: bold;background-color: skyblue ; border : 1px solid black" >Montant</td>
        </tr>
    </thead>
    <?php $__currentLoopData = $formation->teachers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td style="font-size: 13px;font-family: 'arial'; border : 1px solid black"><?php echo e($teacher->user_cin); ?></td>
        <td style="font-size: 13px;font-family: 'arial'; border : 1px solid black"><?php echo e($teacher->user->name()); ?></td>
        <td style="font-size: 13px;font-family: 'arial'; border : 1px solid black"></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH C:\Users\asus\Desktop\Home\resources\views/parts/admin/finance/empty-paiement.blade.php ENDPATH**/ ?>