<?php $paiements = App\Paiement::get()
    ->where('formation_id', $id)
    ->groupBy('date_payement');
$size = sizeof($paiements);

?>
<table>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
    <tr></tr>
</table>
<?php $__currentLoopData = $paiements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $coll_paiements): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $total = 0; ?>
<table>
    <tr></tr>
        <tr>
            <td  colspan="3" style="font-family : 'Times New Roman';border : 1px solid black ; text-align : center; font-size : 14px" ><strong>Paiement des Professeurs, LE <?php echo e($date); ?></strong></td>
        </tr>
        <tr>
            <td style="font-family : 'Times New Roman';border : 1px solid black ; text-align : center; font-size:13px ;  background-color : yellow" colspan="2">Professeur</td>
            <td style="font-family : 'Times New Roman';border : 1px solid black ; text-align : center; font-size:13px ;  background-color : yellow">Montant</td>
        </tr>
        <tbody>

            <?php $__currentLoopData = $coll_paiements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paiement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="font-family : 'Times New Roman';border : 1px solid black ; text-align : center ; font-size : 13px"><?php echo e($paiement->teacher->user_cin); ?></td>
                <td style="font-family : 'Times New Roman';border : 1px solid black ; text-align : center ; font-size : 13px"><?php echo e($paiement->teacher->user->first_name." ".$paiement->teacher->user->last_name); ?></td>
                <td style="font-family : 'Times New Roman';border : 1px solid black ; text-align : center ; font-size : 13px"><?php echo e($paiement->montant); ?></td>
            </tr>
            <?php $total+= $paiement->montant; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="1" style="font-family : 'Times New Roman';border : 1px solid black ; text-align : center; font-size:13px ; font-weight : bold ; background-color : skyblue">Total Paiement</td>
                <td colspan="2" style="font-family : 'Times New Roman';border : 1px solid black ; text-align : center; font-size:13px ; font-weight : bold ; background-color : skyblue"><?php echo e($total); ?></td>
            </tr>
        </tbody>

</table>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/finance/paiements-table.blade.php ENDPATH**/ ?>