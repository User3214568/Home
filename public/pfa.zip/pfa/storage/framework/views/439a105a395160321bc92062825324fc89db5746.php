<table class="table table-bordered  align-middle">
    <?php $count_columns = 0; ?>
    <tr>
        <td rowspan="2"></td>
        <?php $__currentLoopData = $sem->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!isset($auth_modules) || (isset($auth_modules) && in_array($module->id, $auth_modules))): ?>

                <th
                    colspan="<?php echo e(sizeof($module->devoirs->where('session', $session)) > 0 ? sizeof($module->devoirs->where('session', $session)) : 1); ?>">
                    <?php echo e($module->name); ?>

                </th>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    <tr>
        <?php $__currentLoopData = $sem->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!isset($auth_modules) || (isset($auth_modules) && in_array($module->id, $auth_modules))): ?>

                <?php if(sizeof($module->devoirs) > 0): ?>
                    <?php $__currentLoopData = $module->devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devoir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($devoir->session == $session): ?>
                            <td><?php echo e($devoir->name); ?></td>
                            <?php $count_columns++; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php $count_columns++; ?>
                    <td> Aucun Devoir</td>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
    <?php
        $counter = 0;
    ?>
    <?php if(!isset($auth_modules) || sizeof(array_intersect($sem->modules->pluck('id')->toArray(),$auth_modules)) > 0): ?>
    <?php if(sizeof($sem->promotion->etudiants) > 0): ?>
        <?php $__currentLoopData = $sem->promotion->etudiants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etudiant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($etudiant->hasSessionSemestre($sem->id, $session)): ?>
                <tr>
                    <th scope="row"><?php echo e($etudiant->user->name()); ?></th>
                    <?php $__currentLoopData = $sem->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!isset($auth_modules) || (isset($auth_modules) && in_array($module->id, $auth_modules))): ?>

                            <?php if(sizeof($module->devoirs) > 0): ?>
                                <?php $__currentLoopData = $module->devoirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $devoir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($devoir->session == $session): ?>
                                        <?php $evaluation = $etudiant->evaluations->where('devoir_id', $devoir->id)->first(); ?>
                                        <?php if($evaluation): ?>
                                            <td class="border" name="note" id="<?php echo e($evaluation->id); ?>"
                                                contenteditable="true">
                                                <?php echo e($evaluation->note ?: 0); ?>

                                            </td>
                                        <?php else: ?>
                                            <?php if($session == 2): ?>
                                                <td class="border" contenteditable="false">
                                                    Non Rattrappant
                                                </td>
                                            <?php else: ?>
                                                <td class="border">-</td>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <td>Aucune Note</td>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <?php
                    if ($counter == 0) {
                        $counter++;
                    }
                ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if($counter == 0): ?>
            <?php if($session == 1): ?>
                <td colspan="<?php echo e($count_columns + 1); ?>">Aucun Etudiant n'est inscrit dans la session ordinaire de ce
                    Module.</td>
            <?php else: ?>
                <td colspan="<?php echo e($count_columns + 1); ?>">Aucun Etudiant Rattrappant. Verifier bien que vous avez
                    commiter les notes du session ordinaire.</td>
            <?php endif; ?>
        <?php endif; ?>
    <?php else: ?>
        <td colspan="<?php echo e($count_columns + 1); ?>">Aucun Etudiant appartient à cette Promotion</td>
    <?php endif; ?>
<?php else: ?>
    <td colspan="<?php echo e($count_columns + 1); ?>">Vous n'avez pas le droit d'acceder à ce contenu.</td>
    <?php endif; ?>

</table>
<?php /**PATH /home/fedorauser/pfa/resources/views/parts/admin/etudiant/tablenote.blade.php ENDPATH**/ ?>